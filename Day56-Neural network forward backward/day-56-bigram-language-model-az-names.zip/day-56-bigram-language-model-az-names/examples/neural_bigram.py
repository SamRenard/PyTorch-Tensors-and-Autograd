"""Neural bigram model: same predictions as counting, learned by gradient descent.

Also shows that L2 regularisation plays the role of count smoothing.
"""

import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
# Optional: pass your own dataset (one name per line):  python examples/count_bigram.py my_names.txt
DATA_PATH = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "data" / "names_az.txt"

from bigram import CountingBigram, NeuralBigram, Vocab, bigrams, load_names, split_names  # noqa: E402


def main() -> None:
    names = load_names(DATA_PATH)
    train, dev, test = split_names(names, seed=42)
    vocab = Vocab.from_names(names)
    xs, ys = bigrams(train, vocab)
    counting = CountingBigram(vocab).fit(train)

    print(f"training bigrams: {len(xs)} | parameters: {len(vocab)}x{len(vocab)} = {len(vocab) ** 2}")
    print(f"uniform baseline: {math.log(len(vocab)):.4f}")

    # 1) Unregularised training approaches the maximum-likelihood (counting, alpha=0) solution.
    model = NeuralBigram(vocab, seed=0)
    print("\n=== Training without regularisation (lr = 50) ===")
    done = 0
    for upto in (1, 50, 100, 200, 400, 800):
        history = model.fit(xs, ys, epochs=upto - done, lr=50.0)
        done = upto
        print(f"  after {upto:>4} steps | train loss {model.loss(xs, ys):.4f}")
    print(f"  counting optimum (alpha=0): train loss {counting.nll(train, 0.0):.4f}")

    # 2) Regularisation vs smoothing, judged on the dev set.
    print("\n=== L2 regularisation sweep (neural) vs add-alpha smoothing (counting), dev NLL ===")
    best_reg, best_dev, best_model = None, math.inf, None
    for reg in (0.0, 0.003, 0.01, 0.03, 0.1, 0.2, 0.3, 0.5):
        m = NeuralBigram(vocab, seed=0)
        m.fit(xs, ys, epochs=800, lr=50.0, reg=reg)
        dv = m.nll(dev)
        if dv < best_dev:
            best_reg, best_dev, best_model = reg, dv, m
        print(f"  reg={reg:<6} train {m.nll(train):.4f}  dev {dv:.4f}")
    best_alpha = min((0.01, 0.05, 0.1, 0.3, 0.5, 1.0), key=lambda a: counting.nll(dev, a))
    print(f"  best counting model: alpha={best_alpha}  dev {counting.nll(dev, best_alpha):.4f}")
    print(f"  best neural model:   reg={best_reg}  dev {best_dev:.4f}")

    print(f"\nNeural test NLL = {best_model.nll(test):.4f} | counting test NLL = {counting.nll(test, best_alpha):.4f}")

    samples = best_model.sample(20, np.random.default_rng(2147483647), min_len=2)
    print("\nSampled names (neural):")
    print("  " + ", ".join(samples))


if __name__ == "__main__":
    main()
