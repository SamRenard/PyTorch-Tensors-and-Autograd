"""Gradient checking: compare analytic gradients with central finite differences."""

from __future__ import annotations

from typing import Callable, Dict

import numpy as np

Array = np.ndarray


def numerical_gradient(f: Callable[[], float], x: Array, eps: float = 1e-5) -> Array:
    """Central-difference gradient of the scalar ``f()`` with respect to the array ``x``.

    ``x`` is perturbed in place one entry at a time and always restored.
    """
    grad = np.zeros_like(x)
    it = np.nditer(x, flags=["multi_index"])
    for _ in it:
        i = it.multi_index
        original = x[i]
        x[i] = original + eps
        plus = f()
        x[i] = original - eps
        minus = f()
        x[i] = original
        grad[i] = (plus - minus) / (2.0 * eps)
    return grad


def relative_error(a: Array, b: Array) -> float:
    """Norm-based relative error ``||a - b|| / (||a|| + ||b||)``; 0 when both are zero."""
    denom = np.linalg.norm(a) + np.linalg.norm(b)
    return float(np.linalg.norm(a - b) / max(denom, 1e-12))


def check_gradients(net, X: Array, y: Array, eps: float = 1e-5) -> Dict[str, float]:
    """Relative error between ``net.backward`` and numerical gradients, per parameter.

    In float64 a correct implementation typically gives errors below 1e-6.
    """
    net.forward(X)
    analytic = net.backward(y)
    return {
        name: relative_error(analytic[name], numerical_gradient(lambda: net.loss(X, y), net.params[name], eps))
        for name in analytic
    }
