# Day 53 - Concept Notes: Neural Network Forward / Backward

> Personal "second brain" note, based on 3Blue1Brown's *Neural Networks* chapter 1.
> Rewrite the summary in your own words after the video - rephrasing is the learning step.

## Summary (10 sentences)

1. A neuron is a function that takes several numbers, computes a weighted sum, adds a bias, and passes the result through an activation function.
2. The perceptron is the simplest neuron: it outputs a hard 0 or 1 depending on whether the weighted sum crosses a threshold.
3. A layer is many neurons reading the same inputs, so its whole computation collapses into one matrix multiplication: `a = f(XW + b)`.
4. Weights encode *what pattern a neuron looks for*, while the bias encodes *how easily it fires*.
5. Without a non-linear activation, any stack of layers is equivalent to a single linear transformation, so depth would add nothing.
6. Sigmoid and tanh squash values into bounded ranges but saturate, which makes gradients tiny for large inputs.
7. ReLU is cheap and does not saturate for positive inputs, which is why it is the default in most modern networks.
8. For classification, the final layer produces logits that softmax turns into a probability distribution.
9. The forward pass computes a prediction; the loss measures how wrong it is; the backward pass uses the chain rule to find how each parameter changed the loss.
10. Gradient descent then nudges every parameter a small step against its gradient, and repeating this thousands of times is what "learning" means.

## Forward pass

```
z1 = X  @ W1 + b1      shapes: (N, n_in)  @ (n_in, n_hidden)  -> (N, n_hidden)
a1 = f(z1)
z2 = a1 @ W2 + b2      shapes: (N, n_hidden) @ (n_hidden, n_out) -> (N, n_out)
p  = softmax(z2)
L  = -mean(log p[i, y_i])
```

## Backward pass (softmax + cross-entropy)

```
dz2 = (p - one_hot(y)) / N
dW2 = a1.T @ dz2          db2 = sum(dz2, axis=0)
da1 = dz2 @ W2.T
dz1 = da1 * f'(z1)
dW1 = X.T  @ dz1          db1 = sum(dz1, axis=0)
```

## Activation functions

| Function | Formula | Derivative | Range | Notes |
|----------|---------|------------|-------|-------|
| ReLU | `max(0, z)` | `1 if z > 0 else 0` | [0, inf) | Default choice; units can "die" if stuck at 0 |
| Sigmoid | `1 / (1 + e^-z)` | `s(1 - s)` | (0, 1) | Saturates; outputs not zero-centred |
| tanh | `(e^z - e^-z) / (e^z + e^-z)` | `1 - tanh^2(z)` | (-1, 1) | Zero-centred; still saturates |
| Softmax | `e^zi / sum_j e^zj` | see Jacobian | (0, 1), sums to 1 | Output layer for multi-class |

## Parameter counting (the 3B1B network: 784-16-16-10)

- Weights: 784x16 + 16x16 + 16x10 = 12,544 + 256 + 160 = 12,960
- Biases: 16 + 16 + 10 = 42
- Total: **13,002** parameters

The one-hidden-layer network built today (784-16-10) has 12,730.

## Open terms / glossary

- **Perceptron** - a threshold neuron with binary output.
- **Pre-activation (z)** - the weighted sum before the non-linearity.
- **Activation (a)** - the output after the non-linearity.
- **Logits** - raw, unnormalised scores from the last layer.
- **Softmax** - converts logits to a probability distribution.
- **Cross-entropy** - the negative log-probability assigned to the correct class.
- **Vanishing gradient** - gradients shrinking toward zero through saturating activations.
- **Dying ReLU** - a unit whose pre-activation is always negative, so it never receives gradient.
- **Weight initialisation** - He (ReLU) and Xavier (tanh/sigmoid) keep activation variance stable across layers.
- **Gradient checking** - comparing analytic gradients with central finite differences.
- **Log-sum-exp trick** - subtracting the max logit before exponentiating to avoid overflow.

## Common pitfalls

- Mixing up shapes: `(N, n_in) @ (n_in, n_hidden)` - the weight matrix is `(in, out)` here.
- Computing softmax without subtracting the max, producing `inf` / `nan`.
- Forgetting to divide the loss gradient by the batch size.
- Initialising all weights to zero, which makes every hidden neuron identical.
- Applying ReLU on the output layer of a classifier.

## Questions to revisit

- Why does cross-entropy with softmax give such a clean gradient `p - y`?
- How do different initialisations change the very first loss value?
- What does a hidden neuron actually "look for" when the input is a 28x28 image?

## Reflection (fill in after the session)

- Which part of the forward pass was hardest to write from memory?
- What did I refactor after the 5-minute re-read?
