"""Stateless loss functions and their gradients.

Conventions follow ``torch.nn.functional`` so results can be compared directly:

* ``cross_entropy(logits, targets)`` takes raw **logits** of shape ``(N, C)`` and
  **integer class indices** of shape ``(N,)``. Softmax is applied internally, so
  never feed it probabilities.
* ``reduction`` is ``"mean"`` (default), ``"sum"`` or ``"none"``.
* MSE with ``"mean"`` averages over *every element*, not just over the batch.
* ``*_grad`` functions return the gradient of the reduced loss with respect to the
  model output (logits / predictions). For ``reduction="none"`` they assume an upstream
  gradient of 1 for every element, i.e. the gradient of ``loss.sum()``.
"""

from __future__ import annotations

import numpy as np

Array = np.ndarray
REDUCTIONS = ("mean", "sum", "none")


# --------------------------------------------------------------------------- #
# Numerically stable building blocks
# --------------------------------------------------------------------------- #
def logsumexp(z: Array, axis: int = -1, keepdims: bool = False) -> Array:
    """log(sum(exp(z))) without overflow: subtract the max before exponentiating."""
    z = np.asarray(z, dtype=float)
    m = np.max(z, axis=axis, keepdims=True)
    out = m + np.log(np.sum(np.exp(z - m), axis=axis, keepdims=True))
    return out if keepdims else np.squeeze(out, axis=axis)


def log_softmax(z: Array, axis: int = -1) -> Array:
    """log(softmax(z)) = z - logsumexp(z). Never computes log(0)."""
    z = np.asarray(z, dtype=float)
    return z - logsumexp(z, axis=axis, keepdims=True)


def softmax(z: Array, axis: int = -1) -> Array:
    """Probabilities that sum to 1 along ``axis``. Invariant to adding a constant to ``z``."""
    return np.exp(log_softmax(z, axis=axis))


def sigmoid(z: Array) -> Array:
    """Logistic function that never exponentiates a large positive number."""
    z = np.asarray(z, dtype=float)
    e = np.exp(-np.abs(z))
    return np.where(z >= 0, 1.0 / (1.0 + e), e / (1.0 + e))


# --------------------------------------------------------------------------- #
# Validation and reduction helpers
# --------------------------------------------------------------------------- #
def _check_reduction(reduction: str) -> None:
    if reduction not in REDUCTIONS:
        raise ValueError(f"reduction must be one of {REDUCTIONS}, got {reduction!r}")


def _reduce(per_item: Array, reduction: str) -> Array:
    if reduction == "mean":
        return per_item.mean()
    if reduction == "sum":
        return per_item.sum()
    return per_item


def _prepare_classification(logits: Array, targets: Array, label_smoothing: float):
    logits = np.asarray(logits, dtype=float)
    if logits.ndim != 2:
        raise ValueError(f"logits must have shape (N, C), got {logits.shape}")
    targets = np.asarray(targets)
    if targets.shape != (logits.shape[0],):
        raise ValueError(f"targets must have shape ({logits.shape[0]},), got {targets.shape}")
    if not np.issubdtype(targets.dtype, np.integer):
        raise TypeError("targets must be integer class indices, not probabilities or floats")
    if targets.size and (targets.min() < 0 or targets.max() >= logits.shape[1]):
        raise ValueError(f"targets must be in [0, {logits.shape[1]})")
    if not 0.0 <= label_smoothing <= 1.0:
        raise ValueError("label_smoothing must be in [0, 1]")
    return logits, targets


def _prepare_pair(pred: Array, target: Array):
    pred = np.asarray(pred, dtype=float)
    target = np.asarray(target, dtype=float)
    if pred.shape != target.shape:
        raise ValueError(f"prediction and target shapes differ: {pred.shape} vs {target.shape}")
    return pred, target


# --------------------------------------------------------------------------- #
# Cross-entropy (softmax + negative log-likelihood)
# --------------------------------------------------------------------------- #
def cross_entropy(logits: Array, targets: Array, reduction: str = "mean", label_smoothing: float = 0.0):
    """Softmax cross-entropy between logits and integer class targets.

    Per sample: ``-log softmax(logits)[target]``. With label smoothing ``e`` the target
    distribution becomes ``(1 - e) * one_hot + e / C``.
    """
    _check_reduction(reduction)
    logits, targets = _prepare_classification(logits, targets, label_smoothing)
    log_p = log_softmax(logits)
    n = len(targets)
    nll = -log_p[np.arange(n), targets]
    if label_smoothing > 0.0:
        smooth = -log_p.mean(axis=1)  # cross-entropy against the uniform distribution
        per_sample = (1.0 - label_smoothing) * nll + label_smoothing * smooth
    else:
        per_sample = nll
    return _reduce(per_sample, reduction)


def cross_entropy_grad(logits: Array, targets: Array, reduction: str = "mean", label_smoothing: float = 0.0) -> Array:
    """d loss / d logits  =  softmax(logits) - target_distribution  (divided by N for "mean")."""
    _check_reduction(reduction)
    logits, targets = _prepare_classification(logits, targets, label_smoothing)
    n, c = logits.shape
    q = np.full((n, c), label_smoothing / c)
    q[np.arange(n), targets] += 1.0 - label_smoothing
    grad = softmax(logits) - q
    return grad / n if reduction == "mean" else grad


# --------------------------------------------------------------------------- #
# Mean squared error
# --------------------------------------------------------------------------- #
def mse_loss(pred: Array, target: Array, reduction: str = "mean"):
    _check_reduction(reduction)
    pred, target = _prepare_pair(pred, target)
    return _reduce((pred - target) ** 2, reduction)


def mse_loss_grad(pred: Array, target: Array, reduction: str = "mean") -> Array:
    _check_reduction(reduction)
    pred, target = _prepare_pair(pred, target)
    grad = 2.0 * (pred - target)
    return grad / pred.size if reduction == "mean" else grad


# --------------------------------------------------------------------------- #
# Binary cross-entropy on logits
# --------------------------------------------------------------------------- #
def bce_with_logits(logits: Array, targets: Array, reduction: str = "mean"):
    """Stable binary cross-entropy: ``max(x, 0) - x*y + log(1 + exp(-|x|))``.

    Equivalent to ``-[y log s(x) + (1 - y) log(1 - s(x))]`` but never evaluates log(0).
    """
    _check_reduction(reduction)
    x, y = _prepare_pair(logits, targets)
    if y.size and (y.min() < 0.0 or y.max() > 1.0):
        raise ValueError("targets must lie in [0, 1]")
    per_element = np.maximum(x, 0.0) - x * y + np.log1p(np.exp(-np.abs(x)))
    return _reduce(per_element, reduction)


def bce_with_logits_grad(logits: Array, targets: Array, reduction: str = "mean") -> Array:
    """d loss / d logits  =  sigmoid(logits) - targets  (divided by the element count for "mean")."""
    _check_reduction(reduction)
    x, y = _prepare_pair(logits, targets)
    grad = sigmoid(x) - y
    return grad / x.size if reduction == "mean" else grad
