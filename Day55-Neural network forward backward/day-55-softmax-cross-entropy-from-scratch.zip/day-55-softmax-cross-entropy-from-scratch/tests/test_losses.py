"""Tests for softmax, cross-entropy, MSE and BCE.

Values are validated against hand calculations, SciPy, scikit-learn, finite-difference
gradients and (when installed) PyTorch.
"""

import itertools

import numpy as np
import pytest

from losses import (
    REDUCTIONS,
    BCEWithLogitsLoss,
    CrossEntropyLoss,
    MSELoss,
    bce_with_logits,
    bce_with_logits_grad,
    cross_entropy,
    cross_entropy_grad,
    log_softmax,
    logsumexp,
    mse_loss,
    mse_loss_grad,
    numerical_gradient,
    relative_error,
    sigmoid,
    softmax,
)


def ce_data(n=6, c=5, seed=0):
    rng = np.random.default_rng(seed)
    return rng.standard_normal((n, c)) * 2, rng.integers(0, c, size=n)


# ------------------------------ softmax ------------------------------ #
def test_softmax_sums_to_one_and_is_shift_invariant():
    z = np.random.default_rng(0).standard_normal((4, 6))
    p = softmax(z)
    np.testing.assert_allclose(p.sum(axis=1), np.ones(4))
    np.testing.assert_allclose(softmax(z + 123.456), p)


def test_softmax_survives_huge_logits():
    z = np.array([[1000.0, 1001.0, 1002.0], [-1e4, 0.0, 1e4]])
    p = softmax(z)
    assert np.all(np.isfinite(p))
    np.testing.assert_allclose(p.sum(axis=1), [1.0, 1.0])
    assert np.all(np.isfinite(log_softmax(z)))


def test_softmax_and_logsumexp_match_scipy():
    special = pytest.importorskip("scipy.special")
    z = np.random.default_rng(1).standard_normal((5, 7)) * 10
    np.testing.assert_allclose(softmax(z), special.softmax(z, axis=1))
    np.testing.assert_allclose(log_softmax(z), special.log_softmax(z, axis=1))
    np.testing.assert_allclose(logsumexp(z, axis=1), special.logsumexp(z, axis=1))


def test_sigmoid_is_stable():
    out = sigmoid(np.array([-1000.0, 0.0, 1000.0]))
    np.testing.assert_allclose(out, [0.0, 0.5, 1.0], atol=1e-12)


# --------------------------- cross-entropy --------------------------- #
def test_cross_entropy_hand_computed():
    # logits [2, 1, 0.1], target 0: -log(e^2 / (e^2 + e^1 + e^0.1)) = 0.41703...
    loss = cross_entropy(np.array([[2.0, 1.0, 0.1]]), np.array([0]))
    assert loss == pytest.approx(0.417030, abs=1e-5)


def test_cross_entropy_uniform_logits_give_log_c():
    loss = cross_entropy(np.zeros((8, 5)), np.arange(8) % 5)
    assert loss == pytest.approx(np.log(5))


def test_cross_entropy_matches_sklearn_log_loss():
    metrics = pytest.importorskip("sklearn.metrics")
    logits, y = ce_data(n=30, c=4, seed=3)
    expected = metrics.log_loss(y, softmax(logits), labels=list(range(4)))
    assert cross_entropy(logits, y) == pytest.approx(expected, rel=1e-9)


def test_cross_entropy_reductions_are_consistent():
    logits, y = ce_data()
    none = cross_entropy(logits, y, reduction="none")
    assert none.shape == (6,)
    assert cross_entropy(logits, y, "sum") == pytest.approx(none.sum())
    assert cross_entropy(logits, y, "mean") == pytest.approx(none.mean())


def test_cross_entropy_is_finite_for_extreme_logits():
    logits = np.array([[1e4, -1e4, 0.0], [-1e4, 1e4, 0.0]])
    assert np.isfinite(cross_entropy(logits, np.array([0, 1])))
    assert np.isfinite(cross_entropy(logits, np.array([1, 0])))  # confidently wrong: huge but finite


def test_label_smoothing_matches_explicit_target_distribution():
    logits, y = ce_data(n=9, c=4, seed=5)
    eps, c = 0.15, 4
    q = np.full((9, c), eps / c)
    q[np.arange(9), y] += 1 - eps
    expected = -(q * log_softmax(logits)).sum(axis=1).mean()
    assert cross_entropy(logits, y, label_smoothing=eps) == pytest.approx(expected)
    assert cross_entropy(logits, y, label_smoothing=0.0) == pytest.approx(cross_entropy(logits, y))


COMBOS = list(itertools.product(REDUCTIONS, (0.0, 0.2)))


@pytest.mark.parametrize("reduction,smoothing", COMBOS)
def test_cross_entropy_gradient_matches_finite_differences(reduction, smoothing):
    logits, y = ce_data(seed=7)

    def f():
        return float(np.sum(cross_entropy(logits, y, reduction, smoothing)))

    numeric = numerical_gradient(f, logits)
    analytic = cross_entropy_grad(logits, y, reduction, smoothing)
    assert relative_error(analytic, numeric) < 1e-7


def test_cross_entropy_gradient_is_probs_minus_onehot():
    logits, y = ce_data()
    expected = (softmax(logits) - np.eye(5)[y]) / len(y)
    np.testing.assert_allclose(cross_entropy_grad(logits, y), expected)


def test_cross_entropy_rejects_bad_inputs():
    logits = np.zeros((3, 4))
    with pytest.raises(ValueError):
        cross_entropy(logits, np.array([0, 1]))
    with pytest.raises(ValueError):
        cross_entropy(logits, np.array([0, 1, 4]))
    with pytest.raises(TypeError):
        cross_entropy(logits, np.array([0.0, 1.0, 2.0]))  # probabilities / floats are not labels
    with pytest.raises(ValueError):
        cross_entropy(logits, np.array([0, 1, 2]), reduction="avg")
    with pytest.raises(ValueError):
        cross_entropy(logits, np.array([0, 1, 2]), label_smoothing=1.5)
    with pytest.raises(ValueError):
        cross_entropy(np.zeros(4), np.array([0]))


# ------------------------------- MSE --------------------------------- #
def test_mse_hand_computed_and_reductions():
    pred, target = np.array([[1.0, 2.0], [3.0, 4.0]]), np.array([[0.0, 2.0], [5.0, 4.0]])
    assert mse_loss(pred, target) == pytest.approx((1 + 0 + 4 + 0) / 4)  # mean over ALL elements
    assert mse_loss(pred, target, "sum") == pytest.approx(5.0)
    assert mse_loss(pred, target, "none").shape == (2, 2)


@pytest.mark.parametrize("reduction", list(REDUCTIONS))
def test_mse_gradient_matches_finite_differences(reduction):
    rng = np.random.default_rng(2)
    pred, target = rng.standard_normal((4, 3)), rng.standard_normal((4, 3))
    numeric = numerical_gradient(lambda: float(np.sum(mse_loss(pred, target, reduction))), pred)
    assert relative_error(mse_loss_grad(pred, target, reduction), numeric) < 1e-7


def test_mse_rejects_shape_mismatch():
    with pytest.raises(ValueError):
        mse_loss(np.zeros((3, 1)), np.zeros(3))  # would silently broadcast to (3, 3)


# -------------------------------- BCE -------------------------------- #
def test_bce_matches_sklearn_log_loss():
    metrics = pytest.importorskip("sklearn.metrics")
    rng = np.random.default_rng(4)
    x = rng.standard_normal(50) * 3
    y = rng.integers(0, 2, size=50)
    assert bce_with_logits(x, y.astype(float)) == pytest.approx(metrics.log_loss(y, sigmoid(x)), rel=1e-9)


def test_bce_is_stable_where_the_naive_formula_breaks():
    x, y = np.array([-1000.0, 1000.0]), np.array([1.0, 0.0])  # confidently wrong
    out = bce_with_logits(x, y, "none")
    assert np.all(np.isfinite(out))
    np.testing.assert_allclose(out, [1000.0, 1000.0])


@pytest.mark.parametrize("reduction", list(REDUCTIONS))
def test_bce_gradient_matches_finite_differences(reduction):
    rng = np.random.default_rng(6)
    x, y = rng.standard_normal((5, 2)) * 2, rng.integers(0, 2, size=(5, 2)).astype(float)
    numeric = numerical_gradient(lambda: float(np.sum(bce_with_logits(x, y, reduction))), x)
    assert relative_error(bce_with_logits_grad(x, y, reduction), numeric) < 1e-7


def test_bce_rejects_targets_outside_unit_interval():
    with pytest.raises(ValueError):
        bce_with_logits(np.zeros(2), np.array([0.0, 2.0]))


# --------------------------- loss objects ---------------------------- #
def test_loss_objects_match_functional_api():
    logits, y = ce_data()
    ce = CrossEntropyLoss(label_smoothing=0.1)
    assert ce(logits, y) == pytest.approx(cross_entropy(logits, y, label_smoothing=0.1))
    np.testing.assert_allclose(ce.backward(), cross_entropy_grad(logits, y, label_smoothing=0.1))
    np.testing.assert_allclose(ce.backward(2.0), 2.0 * cross_entropy_grad(logits, y, label_smoothing=0.1))

    pred, target = np.random.default_rng(0).standard_normal((2, 3, 4))
    mse = MSELoss()
    assert mse(pred, target) == pytest.approx(mse_loss(pred, target))
    np.testing.assert_allclose(mse.backward(), mse_loss_grad(pred, target))

    x, t = np.array([0.5, -1.0]), np.array([1.0, 0.0])
    bce = BCEWithLogitsLoss()
    assert bce(x, t) == pytest.approx(bce_with_logits(x, t))
    np.testing.assert_allclose(bce.backward(), bce_with_logits_grad(x, t))


def test_reduction_none_accepts_per_sample_upstream_gradient():
    logits, y = ce_data(n=4)
    ce = CrossEntropyLoss(reduction="none")
    ce(logits, y)
    upstream = np.array([1.0, 0.0, 2.0, 0.5])
    expected = cross_entropy_grad(logits, y, "none") * upstream[:, None]
    np.testing.assert_allclose(ce.backward(upstream), expected)


def test_backward_before_forward_raises():
    for loss in (CrossEntropyLoss(), MSELoss(), BCEWithLogitsLoss()):
        with pytest.raises(RuntimeError):
            loss.backward()


def test_softmax_regression_learns_with_these_gradients():
    rng = np.random.default_rng(0)
    centers = np.array([[3.0, 0.0], [-3.0, 0.0], [0.0, 3.0]])
    y = rng.integers(0, 3, size=150)
    X = centers[y] + rng.standard_normal((150, 2))
    W, b = np.zeros((2, 3)), np.zeros(3)
    ce = CrossEntropyLoss()
    first = ce(X @ W + b, y)
    for _ in range(200):
        ce(X @ W + b, y)
        d = ce.backward()
        W -= 0.5 * (X.T @ d)
        b -= 0.5 * d.sum(axis=0)
    assert ce(X @ W + b, y) < first * 0.2
    assert np.mean(np.argmax(X @ W + b, axis=1) == y) > 0.95


# ------------------------------ PyTorch ------------------------------ #
def test_matches_pytorch():
    torch = pytest.importorskip("torch")
    F = torch.nn.functional
    rng = np.random.default_rng(0)

    logits, y = rng.standard_normal((6, 5)) * 3, rng.integers(0, 5, size=6)
    for reduction, smoothing in COMBOS:
        t_logits = torch.tensor(logits, requires_grad=True)
        t_loss = F.cross_entropy(t_logits, torch.tensor(y), reduction=reduction, label_smoothing=smoothing)
        np.testing.assert_allclose(cross_entropy(logits, y, reduction, smoothing), t_loss.detach().numpy(), rtol=1e-10)
        t_loss.sum().backward()
        np.testing.assert_allclose(
            cross_entropy_grad(logits, y, reduction, smoothing), t_logits.grad.numpy(), rtol=1e-8, atol=1e-12
        )

    pred, target = rng.standard_normal((4, 3)), rng.standard_normal((4, 3))
    x, t = rng.standard_normal((4, 3)) * 3, rng.integers(0, 2, size=(4, 3)).astype(float)
    for reduction in REDUCTIONS:
        tp = torch.tensor(pred, requires_grad=True)
        tl = F.mse_loss(tp, torch.tensor(target), reduction=reduction)
        np.testing.assert_allclose(mse_loss(pred, target, reduction), tl.detach().numpy(), rtol=1e-10)
        tl.sum().backward()
        np.testing.assert_allclose(mse_loss_grad(pred, target, reduction), tp.grad.numpy(), rtol=1e-8, atol=1e-12)

        tx = torch.tensor(x, requires_grad=True)
        tb = F.binary_cross_entropy_with_logits(tx, torch.tensor(t), reduction=reduction)
        np.testing.assert_allclose(bce_with_logits(x, t, reduction), tb.detach().numpy(), rtol=1e-10)
        tb.sum().backward()
        np.testing.assert_allclose(bce_with_logits_grad(x, t, reduction), tx.grad.numpy(), rtol=1e-8, atol=1e-12)
