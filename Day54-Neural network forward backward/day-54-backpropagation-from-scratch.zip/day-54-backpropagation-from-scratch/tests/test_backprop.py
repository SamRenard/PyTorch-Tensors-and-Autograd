"""Tests for the MLP: forward, hand-derived backward, gradient checking and training."""

import itertools

import numpy as np
import pytest

from nn_numpy import MLP, check_gradients, naive_backward, numerical_gradient, relative_error

ACTS = ["relu", "sigmoid", "tanh"]
LOSSES = ["cross_entropy", "mse"]
COMBOS = list(itertools.product(ACTS, LOSSES))


def make_data(loss, n=7, n_in=4, n_out=3, seed=0):
    rng = np.random.default_rng(seed)
    X = rng.standard_normal((n, n_in))
    y = rng.integers(0, n_out, size=n) if loss == "cross_entropy" else rng.standard_normal((n, n_out))
    return X, y


# ------------------------------ forward ------------------------------ #
def test_forward_matches_hand_computation():
    net = MLP([2, 2, 2], activation="relu")
    net.params["W1"] = np.array([[1.0, -1.0], [0.5, 2.0]])
    net.params["b1"] = np.array([0.0, 0.5])
    net.params["W2"] = np.array([[1.0, 2.0], [-1.0, 1.0]])
    net.params["b2"] = np.array([0.1, -0.1])
    np.testing.assert_allclose(net.forward(np.array([[2.0, 1.0]])), [[2.1, 5.4]])


def test_parameter_count_and_shapes():
    net = MLP([784, 64, 32, 10])
    assert net.num_parameters() == 784 * 64 + 64 + 64 * 32 + 32 + 32 * 10 + 10
    assert net.forward(np.zeros((5, 784))).shape == (5, 10)


# ------------------------- backward correctness ------------------------ #
@pytest.mark.parametrize("activation,loss", COMBOS)
def test_gradient_check_all_activation_and_loss_combinations(activation, loss):
    net = MLP([4, 5, 3], activation=activation, loss=loss, seed=3)
    X, y = make_data(loss)
    errors = check_gradients(net, X, y)
    assert max(errors.values()) < 1e-6, errors


@pytest.mark.parametrize("depth", [[4, 3], [4, 6, 3], [4, 5, 5, 3], [4, 4, 4, 4, 3]])
def test_gradient_check_for_different_depths(depth):
    net = MLP(depth, activation="tanh", seed=1)
    X, y = make_data("cross_entropy")
    assert max(check_gradients(net, X, y).values()) < 1e-6


def test_gradient_check_with_l2_regularisation():
    net = MLP([4, 6, 3], activation="tanh", l2=0.1, seed=2)
    X, y = make_data("cross_entropy")
    assert max(check_gradients(net, X, y).values()) < 1e-6


@pytest.mark.parametrize("activation,loss", COMBOS)
def test_vectorised_backward_equals_naive_loop_version(activation, loss):
    net = MLP([4, 6, 5, 3], activation=activation, loss=loss, l2=0.05, seed=4)
    X, y = make_data(loss, n=9)
    net.forward(X)
    fast = net.backward(y)
    slow = naive_backward(net, X, y)
    for name in fast:
        np.testing.assert_allclose(fast[name], slow[name], rtol=1e-10, atol=1e-12, err_msg=name)


def test_gradcheck_detects_a_wrong_gradient():
    net = MLP([4, 5, 3], activation="tanh", seed=0)
    X, y = make_data("cross_entropy")
    net.forward(X)
    good = net.backward(y)["W1"]
    numeric = numerical_gradient(lambda: net.loss(X, y), net.params["W1"])
    assert relative_error(good, numeric) < 1e-6
    assert relative_error(good * 1.1, numeric) > 1e-2  # a 10% bug is clearly flagged


def test_relative_error_edge_cases():
    z = np.zeros(3)
    assert relative_error(z, z) == 0.0
    assert relative_error(np.ones(3), np.ones(3)) == 0.0


def test_numerical_gradient_restores_input():
    x = np.array([1.0, 2.0, 3.0])
    before = x.copy()
    numerical_gradient(lambda: float(np.sum(x**2)), x)
    np.testing.assert_array_equal(x, before)


# ------------------------------ training ------------------------------ #
def test_full_batch_training_learns_xor():
    X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=float)
    y = np.array([0, 1, 1, 0])
    net = MLP([2, 8, 2], activation="tanh", seed=0)
    history = net.fit(X, y, epochs=2000, lr=0.5)
    assert history[-1] < history[0] * 0.05
    assert net.accuracy(X, y) == 1.0


def test_minibatch_training_reduces_loss_and_is_reproducible():
    rng = np.random.default_rng(0)
    X = rng.standard_normal((120, 4))
    y = (X[:, 0] + X[:, 1] > 0).astype(int)
    a = MLP([4, 8, 2], seed=0)
    b = MLP([4, 8, 2], seed=0)
    ha = a.fit(X, y, epochs=30, lr=0.1, batch_size=16, seed=5)
    hb = b.fit(X, y, epochs=30, lr=0.1, batch_size=16, seed=5)
    assert ha == hb
    assert ha[-1] < ha[0]


def test_mse_regression_fits_a_linear_target():
    rng = np.random.default_rng(1)
    X = rng.standard_normal((80, 3))
    y = X @ np.array([[1.0], [-2.0], [0.5]]) + 0.3
    net = MLP([3, 1], loss="mse", seed=0)  # a single linear layer
    history = net.fit(X, y, epochs=500, lr=0.1)
    assert history[-1] < 1e-4


def test_l2_shrinks_weights():
    X, y = make_data("cross_entropy", n=40)
    plain = MLP([4, 8, 3], seed=0)
    decayed = MLP([4, 8, 3], l2=0.5, seed=0)
    plain.fit(X, y, epochs=200, lr=0.1)
    decayed.fit(X, y, epochs=200, lr=0.1)
    norm = lambda m: sum(np.sum(m.params[f"W{i}"] ** 2) for i in (1, 2))
    assert norm(decayed) < norm(plain)


# ----------------------------- validation ------------------------------ #
def test_validation_errors():
    net = MLP([3, 4, 2])
    with pytest.raises(ValueError):
        net.forward(np.zeros((5, 4)))
    with pytest.raises(ValueError):
        net.loss(np.zeros((2, 3)), np.array([0, 5]))
    with pytest.raises(TypeError):
        net.loss(np.zeros((2, 3)), np.array([0.0, 1.0]))
    with pytest.raises(RuntimeError):
        MLP([2, 2]).backward(np.array([0]))
    with pytest.raises(ValueError):
        MLP([3])
    with pytest.raises(ValueError):
        MLP([3, 2], activation="swish")
    with pytest.raises(ValueError):
        MLP([3, 2], loss="hinge")
    with pytest.raises(ValueError):
        MLP([3, 1], loss="mse").accuracy(np.zeros((1, 3)), np.zeros(1))
