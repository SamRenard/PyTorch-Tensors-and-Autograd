"""A minimal multi-layer perceptron built on top of :class:`Value`."""

from __future__ import annotations

import random
from typing import List, Optional, Sequence, Union

from .engine import Value


class Module:
    """Base class providing parameter access and gradient reset."""

    def zero_grad(self) -> None:
        for p in self.parameters():
            p.grad = 0.0

    def parameters(self) -> List[Value]:
        return []


class Neuron(Module):
    def __init__(self, n_in: int, activation: str = "tanh", rng: Optional[random.Random] = None) -> None:
        if activation not in {"tanh", "relu", "sigmoid", "linear"}:
            raise ValueError(f"Unknown activation: {activation!r}")
        rng = rng or random
        self.w = [Value(rng.uniform(-1, 1)) for _ in range(n_in)]
        self.b = Value(0.0)
        self.activation = activation

    def __call__(self, x: Sequence[Union[Value, float]]) -> Value:
        act = sum((wi * xi for wi, xi in zip(self.w, x)), self.b)
        if self.activation == "tanh":
            return act.tanh()
        if self.activation == "relu":
            return act.relu()
        if self.activation == "sigmoid":
            return act.sigmoid()
        return act

    def parameters(self) -> List[Value]:
        return self.w + [self.b]

    def __repr__(self) -> str:
        return f"{self.activation.capitalize()}Neuron({len(self.w)})"


class Layer(Module):
    def __init__(self, n_in: int, n_out: int, rng: Optional[random.Random] = None, **kwargs) -> None:
        self.neurons = [Neuron(n_in, rng=rng, **kwargs) for _ in range(n_out)]

    def __call__(self, x):
        out = [n(x) for n in self.neurons]
        return out[0] if len(out) == 1 else out

    def parameters(self) -> List[Value]:
        return [p for n in self.neurons for p in n.parameters()]

    def __repr__(self) -> str:
        return f"Layer of [{', '.join(map(repr, self.neurons))}]"


class MLP(Module):
    """Fully connected network. The last layer is linear by default."""

    def __init__(self, n_in: int, layer_sizes: Sequence[int], seed: Optional[int] = None) -> None:
        rng = random.Random(seed) if seed is not None else None
        sizes = [n_in, *layer_sizes]
        last = len(layer_sizes) - 1
        self.layers = [
            Layer(sizes[i], sizes[i + 1], rng=rng, activation="linear" if i == last else "tanh")
            for i in range(len(layer_sizes))
        ]

    def __call__(self, x):
        for layer in self.layers:
            x = layer(x)
        return x

    def parameters(self) -> List[Value]:
        return [p for layer in self.layers for p in layer.parameters()]

    def __repr__(self) -> str:
        return f"MLP of [{', '.join(map(repr, self.layers))}]"
