"""Print the maximum absolute difference between our losses and PyTorch's.

Requires: pip install torch
Expected: every difference around 1e-15 or smaller (float64 round-off).
"""

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from losses import (  # noqa: E402
    REDUCTIONS,
    bce_with_logits,
    bce_with_logits_grad,
    cross_entropy,
    cross_entropy_grad,
    mse_loss,
    mse_loss_grad,
)

try:
    import torch
    import torch.nn.functional as F
except ImportError:  # pragma: no cover
    sys.exit("This script needs PyTorch:  pip install torch")


def diff(ours, theirs) -> float:
    return float(np.max(np.abs(np.asarray(ours) - theirs.detach().numpy())))


def main() -> None:
    rng = np.random.default_rng(0)
    logits, y = rng.standard_normal((8, 5)) * 3, rng.integers(0, 5, size=8)
    pred, target = rng.standard_normal((8, 3)), rng.standard_normal((8, 3))
    x, t = rng.standard_normal((8, 3)) * 3, rng.integers(0, 2, size=(8, 3)).astype(float)

    print(f"{'loss':<28}{'reduction':<11}{'value diff':>12}{'grad diff':>12}")
    for reduction in REDUCTIONS:
        for smoothing in (0.0, 0.1):
            tl = torch.tensor(logits, requires_grad=True)
            out = F.cross_entropy(tl, torch.tensor(y), reduction=reduction, label_smoothing=smoothing)
            out.sum().backward()
            print(f"{f'cross_entropy (ls={smoothing})':<28}{reduction:<11}"
                  f"{diff(cross_entropy(logits, y, reduction, smoothing), out):>12.2e}"
                  f"{diff(cross_entropy_grad(logits, y, reduction, smoothing), tl.grad):>12.2e}")

        tp = torch.tensor(pred, requires_grad=True)
        out = F.mse_loss(tp, torch.tensor(target), reduction=reduction)
        out.sum().backward()
        print(f"{'mse_loss':<28}{reduction:<11}{diff(mse_loss(pred, target, reduction), out):>12.2e}"
              f"{diff(mse_loss_grad(pred, target, reduction), tp.grad):>12.2e}")

        tx = torch.tensor(x, requires_grad=True)
        out = F.binary_cross_entropy_with_logits(tx, torch.tensor(t), reduction=reduction)
        out.sum().backward()
        print(f"{'bce_with_logits':<28}{reduction:<11}{diff(bce_with_logits(x, t, reduction), out):>12.2e}"
              f"{diff(bce_with_logits_grad(x, t, reduction), tx.grad):>12.2e}")


if __name__ == "__main__":
    main()
