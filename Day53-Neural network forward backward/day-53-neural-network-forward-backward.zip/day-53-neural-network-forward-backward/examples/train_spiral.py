"""Train TwoLayerNet on a 3-class spiral dataset (not linearly separable)."""

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from nn_numpy import TwoLayerNet  # noqa: E402


def make_spirals(points_per_class: int = 100, n_classes: int = 3, noise: float = 0.2, seed: int = 0):
    rng = np.random.default_rng(seed)
    X = np.zeros((points_per_class * n_classes, 2))
    y = np.zeros(points_per_class * n_classes, dtype=int)
    for k in range(n_classes):
        idx = slice(points_per_class * k, points_per_class * (k + 1))
        r = np.linspace(0.0, 1.0, points_per_class)
        t = np.linspace(k * 4, (k + 1) * 4, points_per_class) + rng.standard_normal(points_per_class) * noise
        X[idx] = np.c_[r * np.sin(t), r * np.cos(t)]
        y[idx] = k
    return X, y


def main() -> None:
    X, y = make_spirals()
    net = TwoLayerNet(2, 64, 3, activation="relu", seed=0)
    print(net)
    print(f"Initial loss {net.loss(X, y):.4f} (ln 3 = {np.log(3):.4f}) | accuracy {net.accuracy(X, y):.1%}")

    history = net.fit(X, y, epochs=3000, lr=0.5)
    for epoch in range(0, 3000, 500):
        print(f"epoch {epoch:4d} | loss {history[epoch]:.4f}")
    print(f"Final loss {net.loss(X, y):.4f} | accuracy {net.accuracy(X, y):.1%}")


if __name__ == "__main__":
    main()
