# Gün 55 - Konspekt: Loss funksiyaları, MSE vs Cross-Entropy

## Qısa xülasə

1. Loss modelin proqnozunun nə qədər səhv olduğunu bir ədədlə ölçür, təlim onu azaltmaqdır.
2. MSE proqnoz ilə hədəf fərqinin kvadratıdır və davamlı ədədlər (reqressiya) üçün təbiidir.
3. Softmax logitləri cəmi 1 olan ehtimallara çevirir: `e^zi / Σ e^zj`.
4. Cross-entropy düzgün sinfin ehtimalının mənfi loqarifmidir (`-log p[y]`), əmin olub səhv edəni çox sərt cəzalandırır.
5. Softmax və cross-entropy birlikdə gradienti `p - y`-ə sadələşdirir.
6. Klassifikasiyada MSE sigmoid ilə birlikdə doyduqda gradient yox olur: eyni başlanğıcdan MSE 249, BCE isə cəmi 17 addımda düzəldi.
7. Stabillik üçün exp-dan əvvəl maksimum çıxılır (log-sum-exp), yoxsa böyük logitlərdə `nan` alınır.

## Əsas düsturlar

```
softmax(z)_i  = e^(z_i) / Σ_j e^(z_j)
CE            = -log softmax(z)[y]  =  logsumexp(z) - z[y]
dCE/dz        = p - one_hot(y)
MSE           = mean((pred - target)²)
BCE (logit x) = max(x,0) - x·y + log(1 + e^-|x|)
dBCE/dx       = sigmoid(x) - y
```

## Açar terminlər

- **Logits** - softmax-dan əvvəlki xam ballar
- **Log-sum-exp trick** - `exp`-dan əvvəl maksimumu çıxmaq
- **Negative log-likelihood** - düzgün sinfin mənfi log-ehtimalı
- **Label smoothing** - hədəfi `(1-ε)·one_hot + ε/C` etmək
- **Saturation** - sigmoid/softmax-ın doyması, gradientin sıfıra yaxınlaşması
- **Reduction** - `mean`, `sum`, `none`

## Tipik səhvlər

- PyTorch-da `CrossEntropyLoss`-a softmax çıxışı vermək (ikiqat softmax). O xam logit gözləyir.
- Hədəfi one-hot vermək. `CrossEntropyLoss` sinif indeksi gözləyir.
- MSE-də `mean` bütün elementlər üzrədir, yalnız batch üzrə deyil.
- Klassifikasiyada MSE istifadə etmək.
