"""A deliberately naive, loop-based backward pass.

It processes one sample at a time with explicit vectors and ``np.outer`` so every
step can be read and checked by hand. The vectorised ``MLP.backward`` must agree
with it exactly; it exists to make that equivalence testable and to teach.
"""

from __future__ import annotations

from typing import Dict

import numpy as np

from .activations import softmax

Array = np.ndarray


def naive_backward(net, X: Array, y: Array) -> Dict[str, Array]:
    X = np.asarray(X, dtype=float)
    y = net._prepare_targets(y, len(X))
    n, L, p = len(X), net.L, net.params
    grads = {name: np.zeros_like(v) for name, v in p.items()}

    for x, target in zip(X, y):
        # forward for ONE sample (1-D vectors)
        a = [x]
        z = []
        for i in range(1, L + 1):
            z.append(a[-1] @ p[f"W{i}"] + p[f"b{i}"])
            if i < L:
                a.append(net._act(z[-1]))

        # gradient at the output for ONE sample (the 1/N is applied at the end)
        if net.loss_name == "cross_entropy":
            dz = softmax(z[-1])
            dz[target] -= 1.0
        else:
            dz = 2.0 * (z[-1] - target)

        for i in range(L, 0, -1):
            grads[f"W{i}"] += np.outer(a[i - 1], dz)
            grads[f"b{i}"] += dz
            if i > 1:
                dz = (p[f"W{i}"] @ dz) * net._act_grad(z[i - 2])

    for i in range(1, L + 1):
        grads[f"W{i}"] = grads[f"W{i}"] / n + net.l2 * p[f"W{i}"]
        grads[f"b{i}"] = grads[f"b{i}"] / n
    return grads
