# Gün 54 - Konspekt: Backpropagation riyaziyyatı

## Qısa xülasə

1. Cost funksiyası bütün parametrlərin (çəki və bias) funksiyasıdır, gradient isə onu ən sürətli artıran istiqaməti göstərir.
2. Öyrənmək üçün gradientin əksinə kiçik addımlar atılır (gradient descent).
3. Backpropagation bu gradientləri qatlar boyu sondan əvvələ zəncir qaydası (chain rule) ilə hesablayır.
4. Hər neyron üçün sual belədir: onun çıxışı dəyişsə, loss nə qədər dəyişər?
5. Əvvəlki qatın gradienti sonrakı qatdan gələn gradientin çəki matrisinə vurulması ilə tapılır.
6. Bütün dataya yox, təsadüfi mini-batch-lərə baxmaq (SGD) hər addımı ucuzlaşdırır.
7. Hesabladığımız gradienti həmişə ədədi gradientlə yoxlamaq lazımdır (gradient checking).

## Əsas düsturlar (softmax + cross-entropy)

```
dz2 = (p - one_hot(y)) / N
dW2 = a1ᵀ @ dz2          db2 = sum(dz2)
da1 = dz2 @ W2ᵀ
dz1 = da1 * f'(z1)
dW1 = Xᵀ @ dz1           db1 = sum(dz1)
```

Qayda: `dW[i] = A[i-1]ᵀ @ dZ[i]`, `dZ[i-1] = (dZ[i] @ W[i]ᵀ) * f'(Z[i-1])`

## Açar terminlər

- **Chain rule** - mürəkkəb funksiyanın törəməsi
- **Local gradient** - bir əməliyyatın öz törəməsi
- **SGD / mini-batch** - təsadüfi hissələrlə gradient descent
- **Gradient checking** - analitik gradienti `(L(w+ε) - L(w-ε)) / 2ε` ilə yoxlamaq
- **L2 regularization** - böyük çəkiləri cərimələyir, gradientə `λW` əlavə edir

## Tipik səhvlər

- Gradienti batch ölçüsü `N`-ə bölməyi unutmaq.
- ReLU-nun `z = 0` nöqtəsində gradient yoxlamaq: törəmə orada təyin olunmur, nəticə yalan xəta göstərir.
- Çox böyük `ε` seçmək: kinkin hər iki tərəfinə düşüb səhv ədədi gradient verir.
