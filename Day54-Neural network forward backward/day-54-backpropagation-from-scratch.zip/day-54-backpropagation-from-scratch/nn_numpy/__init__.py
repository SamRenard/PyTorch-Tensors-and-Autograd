"""NumPy-only multi-layer perceptron with a hand-derived backward pass."""

from .activations import ACTIVATIONS, log_softmax, relu, sigmoid, softmax, tanh
from .gradcheck import check_gradients, numerical_gradient, relative_error
from .network import MLP
from .reference import naive_backward

__all__ = [
    "MLP",
    "ACTIVATIONS",
    "relu",
    "sigmoid",
    "tanh",
    "softmax",
    "log_softmax",
    "check_gradients",
    "numerical_gradient",
    "relative_error",
    "naive_backward",
]
__version__ = "0.1.0"
