"""PyTorch tensors and autograd: the same ideas as micrograd, vectorised.

Run with:  python examples/pytorch_basics.py
"""

import torch


def section(title: str) -> None:
    print(f"\n=== {title} ===")


def tensors() -> None:
    section("Creating tensors")
    a = torch.tensor([[1.0, 2.0], [3.0, 4.0]])
    z = torch.zeros(2, 3)
    r = torch.randn(2, 3, generator=torch.Generator().manual_seed(0))
    print("a:", a.tolist(), "| shape", tuple(a.shape), "| dtype", a.dtype)
    print("zeros shape:", tuple(z.shape), "| randn shape:", tuple(r.shape))

    section("Shape manipulation")
    x = torch.arange(12)
    print("view(3, 4):", tuple(x.view(3, 4).shape))
    print("reshape(2, -1):", tuple(x.reshape(2, -1).shape))
    print("unsqueeze(0):", tuple(x.unsqueeze(0).shape))
    print("transpose:", tuple(x.view(3, 4).T.shape))

    section("Broadcasting")
    col = torch.tensor([[1.0], [2.0], [3.0]])  # (3, 1)
    row = torch.tensor([10.0, 20.0, 30.0, 40.0])  # (4,)
    print("(3,1) + (4,) ->", tuple((col + row).shape))

    section("Matrix multiplication")
    w = torch.randn(3, 4, generator=torch.Generator().manual_seed(1))
    v = torch.randn(4, 2, generator=torch.Generator().manual_seed(2))
    print("(3,4) @ (4,2) ->", tuple((w @ v).shape))


def autograd_basics() -> None:
    section("Autograd: scalar example (mirrors micrograd)")
    x1 = torch.tensor(2.0, dtype=torch.double, requires_grad=True)
    x2 = torch.tensor(0.0, dtype=torch.double, requires_grad=True)
    w1 = torch.tensor(-3.0, dtype=torch.double, requires_grad=True)
    w2 = torch.tensor(1.0, dtype=torch.double, requires_grad=True)
    b = torch.tensor(6.8813735870195432, dtype=torch.double, requires_grad=True)
    out = torch.tanh(x1 * w1 + x2 * w2 + b)
    out.backward()
    print(f"out = {out.item():.4f}")
    print(f"x1.grad = {x1.grad.item():.4f}  (micrograd: -1.5)")
    print(f"w1.grad = {w1.grad.item():.4f}  (micrograd:  1.0)")

    section("Gradients accumulate unless zeroed")
    p = torch.tensor(3.0, requires_grad=True)
    for step in range(3):
        (p * p).backward()
        print(f"after backward #{step + 1}: p.grad = {p.grad.item()}")
    p.grad.zero_()
    print("after zero_():", p.grad.item())

    section("no_grad and detach")
    q = torch.tensor([1.0, 2.0], requires_grad=True)
    with torch.no_grad():
        y = q * 2
    print("inside no_grad -> requires_grad:", y.requires_grad)
    print("detach() -> requires_grad:", (q * 2).detach().requires_grad)


def linear_regression() -> None:
    section("Autograd: fit y = 3x + 1 with gradient descent")
    g = torch.Generator().manual_seed(0)
    x = torch.linspace(-1, 1, 64).unsqueeze(1)
    y = 3 * x + 1 + 0.05 * torch.randn(x.shape, generator=g)

    w = torch.zeros(1, 1, requires_grad=True)
    b = torch.zeros(1, requires_grad=True)
    lr = 0.1
    for step in range(200):
        loss = ((x @ w + b - y) ** 2).mean()
        loss.backward()
        with torch.no_grad():
            w -= lr * w.grad
            b -= lr * b.grad
        w.grad.zero_()
        b.grad.zero_()
    print(f"learned w = {w.item():.3f} (true 3.0), b = {b.item():.3f} (true 1.0)")


if __name__ == "__main__":
    tensors()
    autograd_basics()
    linear_regression()
