"""Gradient-check a deeper network, then train it on a 3-class spiral with mini-batch SGD."""

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from nn_numpy import MLP, check_gradients  # noqa: E402


def make_spirals(points_per_class: int = 100, n_classes: int = 3, noise: float = 0.2, seed: int = 0):
    rng = np.random.default_rng(seed)
    X = np.zeros((points_per_class * n_classes, 2))
    y = np.zeros(points_per_class * n_classes, dtype=int)
    for k in range(n_classes):
        idx = slice(points_per_class * k, points_per_class * (k + 1))
        r = np.linspace(0.0, 1.0, points_per_class)
        t = np.linspace(k * 4, (k + 1) * 4, points_per_class) + rng.standard_normal(points_per_class) * noise
        X[idx] = np.c_[r * np.sin(t), r * np.cos(t)]
        y[idx] = k
    return X, y


def main() -> None:
    X, y = make_spirals()
    net = MLP([2, 64, 32, 3], activation="relu", l2=1e-4, seed=0)
    print(net)

    # Skip the first points of each spiral: they sit exactly at (0, 0), where ReLU has a kink
    # (z = 0) and the derivative is undefined, so finite differences and backprop legitimately differ.
    # eps=1e-6 (not 1e-5): a smaller step makes it unlikely that a pre-activation lies within
    # +/-eps of the kink, which would also corrupt the numerical derivative.
    errors = check_gradients(net, X[5:25], y[5:25], eps=1e-6)
    print("\nGradient check (relative error, should be < 1e-6):")
    for name, err in errors.items():
        print(f"  {name}: {err:.2e}")

    print(f"\nBefore training: loss {net.loss(X, y):.4f} | accuracy {net.accuracy(X, y):.1%}")
    history = net.fit(X, y, epochs=300, lr=0.1, batch_size=32, seed=0)
    for epoch in (0, 50, 100, 200, 299):
        print(f"epoch {epoch:3d} | loss {history[epoch]:.4f}")
    print(f"After training:  loss {net.loss(X, y):.4f} | accuracy {net.accuracy(X, y):.1%}")


if __name__ == "__main__":
    main()
