"""Train on the 8x8 handwritten digits bundled with scikit-learn (works offline).

This is a small MNIST-like problem: 1,797 images, 64 features, 10 classes.
Requires: pip install scikit-learn
"""

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from nn_numpy import MLP  # noqa: E402

try:
    from sklearn.datasets import load_digits
except ImportError:  # pragma: no cover
    sys.exit("This example needs scikit-learn:  pip install scikit-learn")


def main() -> None:
    data = load_digits()
    X = data.data / 16.0  # pixel values are 0..16
    y = data.target.astype(int)

    rng = np.random.default_rng(0)
    order = rng.permutation(len(X))
    split = int(0.8 * len(X))
    train, test = order[:split], order[split:]

    net = MLP([64, 64, 32, 10], activation="relu", l2=1e-4, seed=0)
    print(net)
    print(f"train {len(train)} | test {len(test)}")
    print(f"Before training: test accuracy {net.accuracy(X[test], y[test]):.1%}")

    history = net.fit(X[train], y[train], epochs=60, lr=0.1, batch_size=32, seed=0)
    for epoch in (0, 10, 20, 40, 59):
        print(f"epoch {epoch:2d} | train loss {history[epoch]:.4f}")

    print(f"Train accuracy: {net.accuracy(X[train], y[train]):.1%}")
    print(f"Test accuracy:  {net.accuracy(X[test], y[test]):.1%}")


if __name__ == "__main__":
    main()
