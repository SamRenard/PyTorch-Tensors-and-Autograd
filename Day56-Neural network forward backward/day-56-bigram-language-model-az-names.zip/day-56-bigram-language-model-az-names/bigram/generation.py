"""Sampling names from a (V, V) matrix of transition probabilities."""

from __future__ import annotations

from typing import List

import numpy as np

from .data import Vocab


def generate(
    probs: np.ndarray,
    vocab: Vocab,
    n: int,
    rng: np.random.Generator,
    max_len: int = 30,
    min_len: int = 1,
) -> List[str]:
    """Sample ``n`` names. Starts at the ``.`` token and stops when ``.`` is drawn again.

    ``max_len`` guarantees termination even for a model that never emits ``.``. Names shorter
    than ``min_len`` are discarded and redrawn.
    """
    if probs.shape != (len(vocab), len(vocab)):
        raise ValueError(f"probs must have shape {(len(vocab), len(vocab))}, got {probs.shape}")
    names: List[str] = []
    while len(names) < n:
        ix, chars = 0, []
        while True:
            ix = int(rng.choice(len(vocab), p=probs[ix]))
            if ix == 0:
                break
            chars.append(vocab.itos[ix])
            if len(chars) >= max_len:
                break
        if len(chars) >= min_len:
            names.append("".join(chars))
    return names
