# Gün 56 - Konspekt: Bigram dil modeli (makemore #1)

## Qısa xülasə

1. Dil modeli ardıcıllıqda növbəti elementi proqnozlaşdırır, burada bu element hərfdir.
2. Bigram model yalnız əvvəlki bir hərfə baxır: `P(növbəti | cari)`.
3. Counting yanaşmasında hər hərf cütünün sayı hesablanır və hər sətir cəmi 1 olacaq şəkildə normallaşdırılır.
4. Adın əvvəli və sonu `.` tokeni ilə işarələnir ki, model adın nə vaxt bitəcəyini də öyrənsin.
5. Keyfiyyət orta negative log-likelihood (NLL) ilə ölçülür: təsadüfi təxmin `ln 33 = 3.50`, bizim model test setdə `2.53` aldı.
6. Sayı sıfır olan cüt ehtimalı 0 edir və loss-u sonsuz edir, ona görə smoothing (`+α`) lazımdır, α dev setdə seçilir.
7. Neyron bigram `W[x]` + softmax-dır və gradient descent ilə counting modelinin həllinə yaxınlaşır.
8. L2 reqularizasiya smoothing-ə ekvivalentdir: ikisi də ehtimalları bərabər paylanmaya yaxınlaşdırır.
9. Bigramın zəifliyi kontekstin bir hərf olmasıdır, ona görə yaranan adlar çox vaxt uzun və qəribə olur.

## Əsas düsturlar

```
P(j | i)  = (N[i,j] + α) / (Σ_k N[i,k] + α·V)
NLL       = -(1/n) · Σ log P(next | cur)          perplexity = exp(NLL)
logits    = W[x]    (= one_hot(x) @ W)            P = softmax(logits)
loss      = NLL + λ · mean(W²)                    dlogits = (P - one_hot(y)) / n
```

## Açar terminlər

- **Bigram** - ardıcıl iki simvol
- **Token `.`** - adın başlanğıcı və sonu
- **NLL / perplexity** - modelin təəccüb dərəcəsi
- **Smoothing (add-α)** - sıfır sayları aradan qaldırır
- **Train / dev / test** - təlim, hiperparametr seçimi, yekun qiymətləndirmə
- **Sampling** - ehtimal paylanmasından hərf-hərf ad yaratmaq

## Tipik səhvlər

- Python-un `"İ".lower()` nəticəsi 2 simvoldur. Azərbaycan dili üçün `İ → i`, `I → ı` qaydası lazımdır.
- α-nı test setə baxaraq seçmək. Dev set istifadə edin.
- `.` tokenini unutmaq: model adı necə bitirəcəyini bilməz.
- Smoothing olmadan dev/test loss-un `inf` çıxması.
