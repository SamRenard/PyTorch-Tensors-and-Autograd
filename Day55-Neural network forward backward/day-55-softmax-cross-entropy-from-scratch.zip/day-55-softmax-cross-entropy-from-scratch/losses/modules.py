"""Stateful loss objects with a ``forward`` / ``backward`` API (like ``torch.nn`` losses)."""

from __future__ import annotations

from typing import Optional, Tuple

import numpy as np

from . import functional as F

Array = np.ndarray


class _Loss:
    def __init__(self, reduction: str = "mean") -> None:
        F._check_reduction(reduction)
        self.reduction = reduction
        self._cache: Optional[Tuple[Array, Array]] = None

    def _require_cache(self) -> Tuple[Array, Array]:
        if self._cache is None:
            raise RuntimeError("Call the loss (forward) before backward().")
        return self._cache

    def _scale(self, grad: Array, grad_output) -> Array:
        """Apply the upstream gradient (scalar, or per-item array for reduction='none')."""
        grad_output = np.asarray(grad_output, dtype=float)
        if grad_output.ndim == 1 and grad.ndim == 2 and grad_output.shape[0] == grad.shape[0]:
            grad_output = grad_output[:, None]
        return grad * grad_output


class CrossEntropyLoss(_Loss):
    """Softmax + negative log-likelihood. Input: logits (N, C); targets: int class indices (N,)."""

    def __init__(self, reduction: str = "mean", label_smoothing: float = 0.0) -> None:
        super().__init__(reduction)
        if not 0.0 <= label_smoothing <= 1.0:
            raise ValueError("label_smoothing must be in [0, 1]")
        self.label_smoothing = label_smoothing

    def __call__(self, logits: Array, targets: Array):
        value = F.cross_entropy(logits, targets, self.reduction, self.label_smoothing)
        self._cache = (np.asarray(logits, dtype=float), np.asarray(targets))
        return value

    def backward(self, grad_output=1.0) -> Array:
        logits, targets = self._require_cache()
        grad = F.cross_entropy_grad(logits, targets, self.reduction, self.label_smoothing)
        return self._scale(grad, grad_output)


class MSELoss(_Loss):
    def __call__(self, pred: Array, target: Array):
        value = F.mse_loss(pred, target, self.reduction)
        self._cache = (np.asarray(pred, dtype=float), np.asarray(target, dtype=float))
        return value

    def backward(self, grad_output=1.0) -> Array:
        pred, target = self._require_cache()
        return self._scale(F.mse_loss_grad(pred, target, self.reduction), grad_output)


class BCEWithLogitsLoss(_Loss):
    def __call__(self, logits: Array, targets: Array):
        value = F.bce_with_logits(logits, targets, self.reduction)
        self._cache = (np.asarray(logits, dtype=float), np.asarray(targets, dtype=float))
        return value

    def backward(self, grad_output=1.0) -> Array:
        logits, targets = self._require_cache()
        return self._scale(F.bce_with_logits_grad(logits, targets, self.reduction), grad_output)
