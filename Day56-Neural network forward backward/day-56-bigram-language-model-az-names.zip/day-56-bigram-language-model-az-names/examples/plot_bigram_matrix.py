"""Save a heatmap of the bigram count matrix to docs/bigram_matrix.png (needs matplotlib)."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
# Optional: pass your own dataset (one name per line):  python examples/count_bigram.py my_names.txt
DATA_PATH = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "data" / "names_az.txt"

from bigram import CountingBigram, Vocab, load_names  # noqa: E402

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except ImportError:  # pragma: no cover
    sys.exit("This script needs matplotlib:  pip install matplotlib")


def main() -> None:
    names = load_names(DATA_PATH)
    vocab = Vocab.from_names(names)
    counts = CountingBigram(vocab).fit(names).counts
    v = len(vocab)

    fig, ax = plt.subplots(figsize=(11, 11))
    ax.imshow(counts, cmap="Blues")
    for i in range(v):
        for j in range(v):
            if counts[i, j] > 0:
                ax.text(j, i, int(counts[i, j]), ha="center", va="center", fontsize=6,
                        color="white" if counts[i, j] > counts.max() * 0.5 else "black")
    ax.set_xticks(range(v), vocab.itos)
    ax.set_yticks(range(v), vocab.itos)
    ax.xaxis.tick_top()
    ax.xaxis.set_label_position("top")
    ax.set_xlabel("next character")
    ax.set_ylabel("current character  ( . = start / end )")
    ax.set_title("Bigram counts in Azerbaijani names", pad=40)
    fig.tight_layout()

    out = ROOT / "docs" / "bigram_matrix.png"
    out.parent.mkdir(exist_ok=True)
    fig.savefig(out, dpi=130)
    print(f"saved {out}")


if __name__ == "__main__":
    main()
