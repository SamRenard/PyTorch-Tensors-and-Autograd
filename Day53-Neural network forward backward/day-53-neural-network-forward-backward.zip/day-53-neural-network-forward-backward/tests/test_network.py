"""Tests: activations, forward pass, backward pass (gradient checking) and training."""

import numpy as np
import pytest

from nn_numpy import ACTIVATIONS, TwoLayerNet, log_softmax, sigmoid, softmax


def numerical_gradient(f, x, eps=1e-6):
    """Central-difference gradient of scalar f with respect to array x (modified in place)."""
    grad = np.zeros_like(x)
    it = np.nditer(x, flags=["multi_index"])
    for _ in it:
        i = it.multi_index
        old = x[i]
        x[i] = old + eps
        plus = f()
        x[i] = old - eps
        minus = f()
        x[i] = old
        grad[i] = (plus - minus) / (2 * eps)
    return grad


# ---------------------------- activations ---------------------------- #
def test_activation_values():
    z = np.array([-2.0, 0.0, 3.0])
    relu, _ = ACTIVATIONS["relu"]
    tanh, _ = ACTIVATIONS["tanh"]
    np.testing.assert_allclose(relu(z), [0.0, 0.0, 3.0])
    np.testing.assert_allclose(sigmoid(np.array([0.0])), [0.5])
    np.testing.assert_allclose(tanh(z), np.tanh(z))


@pytest.mark.parametrize("name", ["relu", "sigmoid", "tanh"])
def test_activation_gradients_match_finite_differences(name):
    fn, grad = ACTIVATIONS[name]
    z = np.array([-1.7, -0.3, 0.4, 2.2])  # avoids the ReLU kink at 0
    eps = 1e-6
    numeric = (fn(z + eps) - fn(z - eps)) / (2 * eps)
    np.testing.assert_allclose(grad(z), numeric, rtol=1e-5, atol=1e-8)


def test_sigmoid_is_stable():
    out = sigmoid(np.array([-1000.0, 1000.0]))
    assert np.all(np.isfinite(out))
    np.testing.assert_allclose(out, [0.0, 1.0], atol=1e-12)


def test_softmax_rows_sum_to_one_and_survive_huge_logits():
    z = np.array([[1000.0, 1001.0, 1002.0], [-5.0, 0.0, 5.0]])
    p = softmax(z)
    assert np.all(np.isfinite(p))
    np.testing.assert_allclose(p.sum(axis=1), [1.0, 1.0])
    np.testing.assert_allclose(np.exp(log_softmax(z)), p)


# ------------------------------ forward ------------------------------ #
def make_hand_net():
    net = TwoLayerNet(2, 2, 2, activation="relu")
    net.params["W1"] = np.array([[1.0, -1.0], [0.5, 2.0]])
    net.params["b1"] = np.array([0.0, 0.5])
    net.params["W2"] = np.array([[1.0, 2.0], [-1.0, 1.0]])
    net.params["b2"] = np.array([0.1, -0.1])
    return net


def test_forward_matches_hand_computation():
    # x = [2, 1]: z1 = [2.5, 0.5] -> relu -> [2.5, 0.5] -> z2 = [2.1, 5.4]
    net = make_hand_net()
    logits = net.forward(np.array([[2.0, 1.0]]))
    np.testing.assert_allclose(logits, [[2.1, 5.4]])


def test_forward_shapes_for_mnist_sized_network():
    net = TwoLayerNet(784, 16, 10, seed=1)
    X = np.random.default_rng(0).random((32, 784))
    assert net.forward(X).shape == (32, 10)
    assert net.predict_proba(X).shape == (32, 10)
    assert net.num_parameters() == 784 * 16 + 16 + 16 * 10 + 10


def test_input_validation():
    net = TwoLayerNet(3, 4, 2)
    with pytest.raises(ValueError):
        net.forward(np.zeros((5, 4)))
    with pytest.raises(ValueError):
        net.loss(np.zeros((2, 3)), np.array([0, 5]))
    with pytest.raises(TypeError):
        net.loss(np.zeros((2, 3)), np.array([0.0, 1.0]))
    with pytest.raises(ValueError):
        TwoLayerNet(3, 4, 2, activation="swish")


def test_backward_requires_forward():
    with pytest.raises(RuntimeError):
        TwoLayerNet(2, 2, 2).backward(np.array([0]))


# ------------------------------ backward ----------------------------- #
@pytest.mark.parametrize("activation", ["relu", "sigmoid", "tanh"])
def test_backward_matches_numerical_gradients(activation):
    rng = np.random.default_rng(42)
    net = TwoLayerNet(4, 5, 3, activation=activation, seed=7)
    X = rng.standard_normal((6, 4))
    y = rng.integers(0, 3, size=6)

    net.forward(X)
    analytic = net.backward(y)

    for name in ("W1", "b1", "W2", "b2"):
        numeric = numerical_gradient(lambda: net.loss(X, y), net.params[name])
        np.testing.assert_allclose(analytic[name], numeric, rtol=1e-4, atol=1e-7, err_msg=name)


# ------------------------------ training ----------------------------- #
def test_training_learns_xor():
    X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=float)
    y = np.array([0, 1, 1, 0])
    net = TwoLayerNet(2, 8, 2, activation="tanh", seed=0)
    history = net.fit(X, y, epochs=2000, lr=0.5)
    assert history[-1] < history[0] * 0.05
    assert net.accuracy(X, y) == 1.0


def test_initial_loss_close_to_log_num_classes():
    rng = np.random.default_rng(0)
    net = TwoLayerNet(10, 32, 5, seed=0)
    X = rng.standard_normal((200, 10)) * 0.1
    y = rng.integers(0, 5, size=200)
    assert abs(net.loss(X, y) - np.log(5)) < 0.3
