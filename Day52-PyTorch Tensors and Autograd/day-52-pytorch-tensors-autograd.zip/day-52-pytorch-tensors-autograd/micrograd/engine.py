"""Scalar reverse-mode automatic differentiation.

Every :class:`Value` wraps a single float and remembers how it was produced
(its children and the operation). Calling :meth:`Value.backward` walks the
resulting computation graph in reverse topological order and applies the
chain rule at every node.
"""

from __future__ import annotations

import math
from typing import Callable, Iterable, Tuple, Union

Number = Union[int, float]


class Value:
    """A scalar that tracks its gradient through a dynamic computation graph."""

    __slots__ = ("data", "grad", "label", "_backward", "_prev", "_op")

    def __init__(
        self,
        data: Number,
        _children: Iterable["Value"] = (),
        _op: str = "",
        label: str = "",
    ) -> None:
        self.data: float = float(data)
        self.grad: float = 0.0  # d(output)/d(self), filled by backward()
        self.label = label
        self._backward: Callable[[], None] = lambda: None
        self._prev: Tuple["Value", ...] = tuple(_children)
        self._op = _op

    # ------------------------------------------------------------------ #
    # Basic arithmetic
    # ------------------------------------------------------------------ #
    def __add__(self, other: Union["Value", Number]) -> "Value":
        other = other if isinstance(other, Value) else Value(other)
        out = Value(self.data + other.data, (self, other), "+")

        def _backward() -> None:
            # d(a+b)/da = 1, d(a+b)/db = 1
            self.grad += out.grad
            other.grad += out.grad

        out._backward = _backward
        return out

    def __mul__(self, other: Union["Value", Number]) -> "Value":
        other = other if isinstance(other, Value) else Value(other)
        out = Value(self.data * other.data, (self, other), "*")

        def _backward() -> None:
            # d(a*b)/da = b, d(a*b)/db = a
            self.grad += other.data * out.grad
            other.grad += self.data * out.grad

        out._backward = _backward
        return out

    def __pow__(self, exponent: Number) -> "Value":
        if not isinstance(exponent, (int, float)):
            raise TypeError("Only int/float exponents are supported.")
        out = Value(self.data**exponent, (self,), f"**{exponent}")

        def _backward() -> None:
            # d(a^n)/da = n * a^(n-1)
            self.grad += exponent * (self.data ** (exponent - 1)) * out.grad

        out._backward = _backward
        return out

    # ------------------------------------------------------------------ #
    # Non-linearities and elementary functions
    # ------------------------------------------------------------------ #
    def tanh(self) -> "Value":
        t = math.tanh(self.data)
        out = Value(t, (self,), "tanh")

        def _backward() -> None:
            self.grad += (1.0 - t * t) * out.grad

        out._backward = _backward
        return out

    def relu(self) -> "Value":
        out = Value(self.data if self.data > 0 else 0.0, (self,), "relu")

        def _backward() -> None:
            self.grad += (1.0 if out.data > 0 else 0.0) * out.grad

        out._backward = _backward
        return out

    def sigmoid(self) -> "Value":
        # Numerically stable formulation.
        x = self.data
        s = 1.0 / (1.0 + math.exp(-x)) if x >= 0 else math.exp(x) / (1.0 + math.exp(x))
        out = Value(s, (self,), "sigmoid")

        def _backward() -> None:
            self.grad += s * (1.0 - s) * out.grad

        out._backward = _backward
        return out

    def exp(self) -> "Value":
        e = math.exp(self.data)
        out = Value(e, (self,), "exp")

        def _backward() -> None:
            self.grad += e * out.grad

        out._backward = _backward
        return out

    def log(self) -> "Value":
        if self.data <= 0:
            raise ValueError("log() is only defined for positive values.")
        out = Value(math.log(self.data), (self,), "log")

        def _backward() -> None:
            self.grad += (1.0 / self.data) * out.grad

        out._backward = _backward
        return out

    # ------------------------------------------------------------------ #
    # Backpropagation
    # ------------------------------------------------------------------ #
    def backward(self) -> None:
        """Compute d(self)/d(node) for every node in the graph.

        The topological sort is iterative, so very deep graphs do not hit
        Python's recursion limit.
        """
        topo: list[Value] = []
        visited: set[int] = set()
        stack: list[Tuple[Value, bool]] = [(self, False)]
        while stack:
            node, children_done = stack.pop()
            if children_done:
                topo.append(node)
                continue
            if id(node) in visited:
                continue
            visited.add(id(node))
            stack.append((node, True))
            for child in node._prev:
                if id(child) not in visited:
                    stack.append((child, False))

        self.grad = 1.0  # seed: d(self)/d(self) = 1
        for node in reversed(topo):
            node._backward()

    # ------------------------------------------------------------------ #
    # Derived operators (built from the primitives above)
    # ------------------------------------------------------------------ #
    def __neg__(self) -> "Value":
        return self * -1

    def __sub__(self, other: Union["Value", Number]) -> "Value":
        return self + (-other)

    def __truediv__(self, other: Union["Value", Number]) -> "Value":
        return self * other**-1

    def __radd__(self, other: Number) -> "Value":
        return self + other

    def __rsub__(self, other: Number) -> "Value":
        return (-self) + other

    def __rmul__(self, other: Number) -> "Value":
        return self * other

    def __rtruediv__(self, other: Number) -> "Value":
        return other * self**-1

    def __repr__(self) -> str:
        name = f", label={self.label!r}" if self.label else ""
        return f"Value(data={self.data:.6g}, grad={self.grad:.6g}{name})"
