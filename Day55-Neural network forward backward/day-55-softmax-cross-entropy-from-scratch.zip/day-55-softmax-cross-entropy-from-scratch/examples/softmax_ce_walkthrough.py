"""Softmax + cross-entropy, one step at a time, plus why numerical stability matters."""

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from losses import cross_entropy, cross_entropy_grad, softmax  # noqa: E402

np.set_printoptions(precision=5, suppress=True)


def step_by_step() -> None:
    print("=== Step by step ===")
    logits = np.array([2.0, 1.0, 0.1])
    target = 0
    print("logits                 =", logits, f"| true class = {target}")

    shifted = logits - logits.max()
    print("subtract max (stable)  =", shifted)
    exps = np.exp(shifted)
    print("exp                    =", exps)
    probs = exps / exps.sum()
    print("softmax = exp / sum    =", probs, f"| sum = {probs.sum():.1f}")
    loss = -np.log(probs[target])
    print(f"loss = -log(p[target]) = {loss:.5f}")

    one_hot = np.eye(3)[target]
    print("gradient = p - one_hot =", probs - one_hot)

    assert np.isclose(loss, cross_entropy(logits[None], np.array([target])))
    assert np.allclose(probs - one_hot, cross_entropy_grad(logits[None], np.array([target]))[0])
    print("Library result agrees with the manual computation.\n")


def what_the_loss_means() -> None:
    print("=== What the loss rewards ===")
    for p_true in (0.99, 0.9, 0.5, 0.1, 0.01):
        print(f"  probability on the true class {p_true:>5}  ->  loss {-np.log(p_true):.3f}")
    print("Confident and wrong is punished far harder than uncertain.\n")


def stability() -> None:
    print("=== Numerical stability ===")
    logits = np.array([1000.0, 1001.0, 1002.0])

    with np.errstate(all="ignore"):
        naive = np.exp(logits) / np.exp(logits).sum()
    print("naive  exp(z)/sum(exp(z)) =", naive, " <- inf / inf = nan")
    print("stable softmax            =", softmax(logits))
    print("stable cross-entropy      =", cross_entropy(logits[None], np.array([2])))

    extreme = np.array([[1e4, -1e4, 0.0]])
    print("confidently wrong (logit gap 2e4):", cross_entropy(extreme, np.array([1])), "(large but finite)")


if __name__ == "__main__":
    step_by_step()
    what_the_loss_means()
    stability()
