"""Why classification uses cross-entropy instead of MSE.

A single logistic neuron predicts p = sigmoid(w * x). We start it confidently wrong and
compare how fast gradient descent recovers under MSE and under binary cross-entropy.
"""

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from losses import bce_with_logits, bce_with_logits_grad, mse_loss, mse_loss_grad, sigmoid  # noqa: E402


def gradient_table() -> None:
    print("=== Gradient w.r.t. the logit z when the true label is 1 ===")
    print(f"{'z':>5} {'p=sigmoid(z)':>14} {'MSE grad':>12} {'BCE grad':>12}")
    for z in (-8.0, -6.0, -4.0, -2.0, 0.0, 2.0):
        p = sigmoid(np.array(z))
        # MSE acts on p, so the chain rule adds the sigmoid derivative p(1-p), which vanishes when saturated.
        g_mse = float(mse_loss_grad(p, np.array(1.0))) * float(p * (1 - p))
        g_bce = float(bce_with_logits_grad(np.array(z), np.array(1.0)))
        print(f"{z:>5.1f} {float(p):>14.6f} {g_mse:>12.6f} {g_bce:>12.6f}")
    print("When the model is confidently wrong (z = -8) MSE barely moves; BCE still pushes hard.\n")


def steps_to_recover(loss_name: str, w0: float = -6.0, lr: float = 1.0, target_p: float = 0.9, max_steps: int = 100_000):
    x, y = np.array(1.0), np.array(1.0)
    w = np.array(w0)
    for step in range(max_steps + 1):
        z = w * x
        p = sigmoid(z)
        if p >= target_p:
            return step
        if loss_name == "mse":
            dz = mse_loss_grad(p, y) * p * (1 - p)
        else:
            dz = bce_with_logits_grad(z, y)
        w = w - lr * dz * x
    return None


def training_race() -> None:
    print("=== Gradient-descent steps until p(true class) >= 0.9 ===")
    print(f"start: w = -6  ->  p = {float(sigmoid(np.array(-6.0))):.4f}   (learning rate 1.0)")
    print(f"  initial MSE loss = {float(mse_loss(sigmoid(np.array(-6.0)), np.array(1.0))):.4f}"
          f" | initial BCE loss = {float(bce_with_logits(np.array(-6.0), np.array(1.0))):.4f}")
    for name in ("mse", "bce"):
        steps = steps_to_recover(name)
        print(f"  {name.upper():<4} -> {steps if steps is not None else '> 100000'} steps")


if __name__ == "__main__":
    gradient_table()
    training_race()
