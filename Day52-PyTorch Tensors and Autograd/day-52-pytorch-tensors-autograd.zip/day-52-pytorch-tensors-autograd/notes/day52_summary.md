# Day 52 - Concept Notes: Backpropagation, Tensors & Autograd

> Personal "second brain" note. Re-read and rephrase in your own words
> after watching the lecture - the act of rewriting is what makes it stick.

## Summary (in 10 sentences)

1. A neural network is a differentiable function, and training means nudging its parameters to reduce a scalar loss.
2. The gradient of the loss with respect to a parameter tells us how much, and in which direction, that parameter affects the loss.
3. Every computation can be recorded as a directed acyclic graph whose nodes are values and whose edges are operations.
4. Backpropagation is simply the chain rule applied to that graph, starting from the output and moving toward the inputs.
5. Each node only needs to know its *local* derivative; the global gradient is the local derivative multiplied by the gradient arriving from above.
6. When a value is used in more than one place, its gradients from every use are summed, which is why the code uses `+=` instead of `=`.
7. A topological ordering guarantees that a node's gradient is fully accumulated before it is passed on to its children.
8. Gradients from a previous step must be reset to zero before the next backward pass, otherwise they silently accumulate.
9. PyTorch does exactly what micrograd does, but on n-dimensional tensors with optimised kernels, so one node represents thousands of scalar operations.
10. Understanding the scalar version makes `loss.backward()` and `optimizer.step()` feel like mechanics rather than magic.

## Key formulas

| Operation | Forward | Local derivative |
|-----------|---------|------------------|
| Add | `c = a + b` | `dc/da = 1`, `dc/db = 1` |
| Multiply | `c = a * b` | `dc/da = b`, `dc/db = a` |
| Power | `c = a^n` | `dc/da = n * a^(n-1)` |
| tanh | `c = tanh(a)` | `dc/da = 1 - c^2` |
| ReLU | `c = max(0, a)` | `dc/da = 1 if a > 0 else 0` |
| Sigmoid | `c = 1/(1+e^-a)` | `dc/da = c * (1 - c)` |
| exp | `c = e^a` | `dc/da = c` |
| log | `c = ln(a)` | `dc/da = 1/a` |

Chain rule: `dL/dx = dL/dy * dy/dx`

## Open terms / glossary

- **Computation graph** - the DAG of operations that produced a value.
- **Forward pass** - evaluating the graph from inputs to output.
- **Backward pass** - propagating gradients from the output back to the inputs.
- **Local gradient** - the derivative of a node's output with respect to its direct input.
- **Gradient accumulation** - summing gradients when a node feeds multiple consumers.
- **Topological sort** - an ordering of nodes where every node appears after all its dependencies.
- **Leaf tensor** - a tensor created by the user (not the result of an op); holds `.grad` when `requires_grad=True`.
- **Dynamic graph (define-by-run)** - the graph is rebuilt on every forward pass (PyTorch, micrograd).
- **Broadcasting** - implicit expansion of tensor shapes for elementwise ops.
- **`torch.no_grad()`** - disables graph construction, used for inference and optimiser updates.
- **`detach()`** - returns a tensor that shares data but is cut from the graph.

## Common pitfalls

- Forgetting `zero_grad()` so gradients from earlier steps leak into the current one.
- Using `=` instead of `+=` in `_backward`, which breaks any graph where a node is reused.
- Calling `.backward()` on a non-scalar tensor without passing a `gradient` argument.
- Doing in-place updates on leaf tensors that require grad outside of `torch.no_grad()`.

## Questions to revisit

- Why does PyTorch free the graph after `backward()` by default, and when is `retain_graph=True` needed?
- How do vector-Jacobian products avoid materialising full Jacobians?
- What changes in the backward rule when an op is not element-wise (e.g. matmul)?

## Reflection (fill in after the session)

- What was hardest to rebuild from memory?
- What did I refactor after the 5-minute re-read?
