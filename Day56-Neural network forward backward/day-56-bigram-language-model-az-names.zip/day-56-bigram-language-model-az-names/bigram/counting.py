"""The counting bigram model: P(next | current) estimated from a table of counts."""

from __future__ import annotations

from typing import List, Sequence

import numpy as np

from .data import Vocab, bigrams
from .generation import generate


class CountingBigram:
    """Stores ``counts[i, j]`` = how often character ``j`` follows character ``i``."""

    def __init__(self, vocab: Vocab) -> None:
        self.vocab = vocab
        self.counts = np.zeros((len(vocab), len(vocab)))

    def fit(self, names: Sequence[str]) -> "CountingBigram":
        xs, ys = bigrams(names, self.vocab)
        np.add.at(self.counts, (xs, ys), 1)
        return self

    def probs(self, alpha: float = 0.0) -> np.ndarray:
        """Row-normalised probabilities. ``alpha`` is add-alpha (Laplace) smoothing."""
        if alpha < 0:
            raise ValueError("alpha must be non-negative")
        c = self.counts + alpha
        totals = c.sum(axis=1, keepdims=True)
        uniform = np.full_like(c, 1.0 / c.shape[1])
        return np.divide(c, totals, out=uniform, where=totals > 0)  # unseen rows fall back to uniform

    def nll(self, names: Sequence[str], alpha: float = 0.0) -> float:
        """Average negative log-likelihood per bigram. ``inf`` if any bigram has probability 0."""
        xs, ys = bigrams(names, self.vocab)
        p = self.probs(alpha)[xs, ys]
        with np.errstate(divide="ignore"):
            return float(-np.mean(np.log(p)))

    def sample(self, n: int, rng: np.random.Generator, alpha: float = 0.0, **kwargs) -> List[str]:
        return generate(self.probs(alpha), self.vocab, n, rng, **kwargs)

    def top_bigrams(self, k: int = 10):
        flat = np.argsort(self.counts, axis=None)[::-1][:k]
        pairs = [np.unravel_index(i, self.counts.shape) for i in flat]
        return [(self.vocab.itos[i] + self.vocab.itos[j], int(self.counts[i, j])) for i, j in pairs]
