"""Numerically stable softmax helpers."""

from __future__ import annotations

import numpy as np

Array = np.ndarray


def log_softmax(z: Array, axis: int = -1) -> Array:
    z = np.asarray(z, dtype=float)
    shifted = z - np.max(z, axis=axis, keepdims=True)
    return shifted - np.log(np.sum(np.exp(shifted), axis=axis, keepdims=True))


def softmax(z: Array, axis: int = -1) -> Array:
    return np.exp(log_softmax(z, axis=axis))
