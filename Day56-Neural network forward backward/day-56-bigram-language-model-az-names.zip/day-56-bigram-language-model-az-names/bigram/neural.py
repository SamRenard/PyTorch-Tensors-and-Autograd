"""The neural bigram model: a single weight matrix trained by gradient descent.

``logits = one_hot(x) @ W`` is just row ``x`` of ``W``, so the forward pass is an indexing
operation. Training minimises the average negative log-likelihood plus an optional L2 term,
and (without regularisation) converges to the counting model.
"""

from __future__ import annotations

from typing import List, Optional, Sequence

import numpy as np

from .data import Vocab, bigrams
from .functional import log_softmax, softmax
from .generation import generate


class NeuralBigram:
    def __init__(self, vocab: Vocab, seed: Optional[int] = 0) -> None:
        self.vocab = vocab
        v = len(vocab)
        self.W = np.random.default_rng(seed).standard_normal((v, v))

    def logits(self, xs: np.ndarray) -> np.ndarray:
        return self.W[xs]  # identical to one_hot(xs) @ W, without building the one-hot matrix

    def loss(self, xs: np.ndarray, ys: np.ndarray, reg: float = 0.0) -> float:
        """Mean negative log-likelihood + ``reg * mean(W ** 2)``."""
        log_p = log_softmax(self.logits(xs))
        nll = -np.mean(log_p[np.arange(len(ys)), ys])
        return float(nll + reg * np.mean(self.W**2))

    def grad(self, xs: np.ndarray, ys: np.ndarray, reg: float = 0.0) -> np.ndarray:
        n = len(ys)
        d_logits = softmax(self.logits(xs))
        d_logits[np.arange(n), ys] -= 1.0  # softmax + cross-entropy: p - one_hot
        d_logits /= n
        dW = np.zeros_like(self.W)
        np.add.at(dW, xs, d_logits)  # scatter-add: rows of W used several times accumulate
        return dW + reg * 2.0 * self.W / self.W.size

    def fit(
        self,
        xs: np.ndarray,
        ys: np.ndarray,
        epochs: int = 200,
        lr: float = 50.0,
        reg: float = 0.0,
    ) -> List[float]:
        """Full-batch gradient descent. Returns the loss before every update."""
        history: List[float] = []
        for _ in range(epochs):
            history.append(self.loss(xs, ys, reg))
            self.W -= lr * self.grad(xs, ys, reg)
        return history

    def probs(self) -> np.ndarray:
        return softmax(self.W)  # row i = P(next | current = i)

    def nll(self, names: Sequence[str]) -> float:
        xs, ys = bigrams(names, self.vocab)
        return self.loss(xs, ys, reg=0.0)

    def sample(self, n: int, rng: np.random.Generator, **kwargs) -> List[str]:
        return generate(self.probs(), self.vocab, n, rng, **kwargs)
