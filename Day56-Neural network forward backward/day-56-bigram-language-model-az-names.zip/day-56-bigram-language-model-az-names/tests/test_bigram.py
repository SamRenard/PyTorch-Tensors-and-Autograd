"""Tests for data handling, the counting model, the neural model and sampling."""

import math
import os
import tempfile

import numpy as np
import pytest

from bigram import (
    AZ_ALPHABET,
    CountingBigram,
    NeuralBigram,
    Vocab,
    az_lower,
    bigrams,
    generate,
    load_names,
    split_names,
)

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data", "names_az.txt")


def write_tmp(text):
    f = tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8")
    f.write(text)
    f.close()
    return f.name


# ------------------------------ text handling ------------------------------ #
def test_az_lower_handles_dotted_and_dotless_i():
    assert az_lower("İLHAM") == "ilham"
    assert az_lower("ILHAM") == "ılham"
    assert az_lower("ƏLİ") == "əli"
    assert az_lower("ŞÜKÜR") == "şükür"
    assert len(az_lower("İ")) == 1


def test_python_default_lower_would_break_names():
    # Documents the pitfall az_lower exists to avoid.
    assert len("İ".lower()) == 2


def test_load_names_normalises_dedupes_and_skips_comments():
    path = write_tmp("# comment\nİlham\n\n  Əli \nİLHAM\nşükür\n")
    assert load_names(path) == ["ilham", "əli", "şükür"]
    assert load_names(path, unique=False) == ["ilham", "əli", "ilham", "şükür"]


def test_load_names_rejects_non_letters_and_empty_files():
    with pytest.raises(ValueError):
        load_names(write_tmp("Ali Veli\n"))
    with pytest.raises(ValueError):
        load_names(write_tmp("ali1\n"))
    with pytest.raises(ValueError):
        load_names(write_tmp("# only a comment\n"))


def test_bundled_dataset_is_clean():
    names = load_names(DATA)
    assert len(names) == len(set(names)) >= 300
    assert all(set(n) <= set(AZ_ALPHABET) for n in names), "name uses a non-Azerbaijani letter"
    assert all(2 <= len(n) <= 15 for n in names)


def test_split_is_deterministic_disjoint_and_complete():
    names = [f"n{i}" for i in range(100)]
    a, b = split_names(names, seed=1), split_names(names, seed=1)
    assert a == b
    train, dev, test = a
    assert (len(train), len(dev), len(test)) == (80, 10, 10)
    assert sorted(train + dev + test) == sorted(names)
    assert split_names(names, seed=2) != a
    with pytest.raises(ValueError):
        split_names(names, fractions=(0.5, 0.5, 0.5))


def test_vocab_roundtrip_and_special_token():
    vocab = Vocab.from_names(["əli", "şən"])
    assert vocab.itos[0] == "."
    assert len(vocab) == 1 + len(set("əlişn"))
    assert vocab.decode(vocab.encode("əli")) == "əli"
    with pytest.raises(KeyError):
        vocab.encode("z")


def test_bigram_pairs_include_start_and_end_padding():
    vocab = Vocab.from_names(["ab"])
    xs, ys = bigrams(["ab"], vocab)
    assert vocab.decode(xs) == ".ab"
    assert vocab.decode(ys) == "ab."


# ------------------------------ counting model ----------------------------- #
def test_counts_hand_computed():
    names = ["ab", "ac"]
    vocab = Vocab.from_names(names)
    model = CountingBigram(vocab).fit(names)
    s = vocab.stoi
    assert model.counts[s["."], s["a"]] == 2
    assert model.counts[s["a"], s["b"]] == 1
    assert model.counts.sum() == 6  # 3 bigrams per name
    p = model.probs()
    assert p[s["a"], s["b"]] == pytest.approx(0.5)
    # Only a -> b/c is uncertain: mean NLL = (2 * ln 2) / 6 = ln 2 / 3
    assert model.nll(names) == pytest.approx(math.log(2) / 3)


def test_rows_sum_to_one_for_every_alpha():
    names = load_names(DATA)
    model = CountingBigram(Vocab.from_names(names)).fit(names)
    for alpha in (0.0, 0.01, 1.0, 10.0):
        np.testing.assert_allclose(model.probs(alpha).sum(axis=1), 1.0)


def test_unseen_bigram_is_infinite_without_smoothing_and_finite_with():
    vocab = Vocab.from_names(["ab", "ba"])
    model = CountingBigram(vocab).fit(["ab"])
    assert model.nll(["ba"], alpha=0.0) == math.inf
    assert math.isfinite(model.nll(["ba"], alpha=0.5))


def test_more_smoothing_pulls_towards_uniform():
    names = load_names(DATA)
    model = CountingBigram(Vocab.from_names(names)).fit(names)
    uniform = math.log(len(model.vocab))
    train_nll = [model.nll(names, a) for a in (0.0, 0.1, 1.0, 10.0, 100.0, 1e6)]
    assert train_nll == sorted(train_nll)  # on the training data, smoothing only ever hurts
    assert train_nll[-1] == pytest.approx(uniform, abs=1e-3)  # huge alpha -> uniform model, loss ln(V)


def test_alpha_must_be_non_negative():
    with pytest.raises(ValueError):
        CountingBigram(Vocab.from_names(["a"])).probs(-1)


def test_top_bigrams_are_sorted():
    names = load_names(DATA)
    top = CountingBigram(Vocab.from_names(names)).fit(names).top_bigrams(5)
    counts = [c for _, c in top]
    assert counts == sorted(counts, reverse=True)


# ------------------------------ neural model ------------------------------- #
def test_indexing_equals_one_hot_matmul():
    vocab = Vocab.from_names(["əli", "leyla"])
    model = NeuralBigram(vocab, seed=3)
    xs = np.array([0, 2, 2, 1])
    one_hot = np.eye(len(vocab))[xs]
    np.testing.assert_allclose(model.logits(xs), one_hot @ model.W)


def test_gradient_matches_finite_differences():
    names = ["əli", "leyla", "anar"]
    vocab = Vocab.from_names(names)
    xs, ys = bigrams(names, vocab)
    model = NeuralBigram(vocab, seed=1)
    reg = 0.05
    analytic = model.grad(xs, ys, reg)

    numeric, eps = np.zeros_like(model.W), 1e-6
    for i in range(model.W.shape[0]):
        for j in range(model.W.shape[1]):
            old = model.W[i, j]
            model.W[i, j] = old + eps
            plus = model.loss(xs, ys, reg)
            model.W[i, j] = old - eps
            minus = model.loss(xs, ys, reg)
            model.W[i, j] = old
            numeric[i, j] = (plus - minus) / (2 * eps)
    rel = np.linalg.norm(analytic - numeric) / (np.linalg.norm(analytic) + np.linalg.norm(numeric))
    assert rel < 1e-7


def test_initial_loss_is_near_uniform_baseline_for_zero_weights():
    names = load_names(DATA)
    vocab = Vocab.from_names(names)
    xs, ys = bigrams(names, vocab)
    model = NeuralBigram(vocab)
    model.W[:] = 0.0
    assert model.loss(xs, ys) == pytest.approx(math.log(len(vocab)))


def test_training_reduces_loss_but_cannot_beat_the_counting_optimum():
    names = load_names(DATA)
    vocab = Vocab.from_names(names)
    xs, ys = bigrams(names, vocab)
    history = NeuralBigram(vocab, seed=0).fit(xs, ys, epochs=100, lr=50.0)
    assert history[-1] < history[0] * 0.7
    assert all(b <= a + 1e-9 for a, b in zip(history, history[1:]))  # monotone for full-batch GD here
    # Counting (alpha=0) is the maximum-likelihood solution: no unregularised model can go below it.
    mle = CountingBigram(vocab).fit(names).nll(names, alpha=0.0)
    assert history[-1] > mle - 1e-9


def test_neural_model_converges_to_the_counting_model():
    names = ["leyla", "əli", "aysel", "anar", "elnur", "ayla", "nigar", "vüsal"]
    vocab = Vocab.from_names(names)
    xs, ys = bigrams(names, vocab)
    counting = CountingBigram(vocab).fit(names).nll(names, alpha=0.0)
    neural = NeuralBigram(vocab, seed=0)
    neural.fit(xs, ys, epochs=6000, lr=30.0)
    assert neural.nll(names) == pytest.approx(counting, abs=0.02)


def test_l2_regularisation_shrinks_weights():
    names = load_names(DATA)
    vocab = Vocab.from_names(names)
    xs, ys = bigrams(names, vocab)
    plain, reg = NeuralBigram(vocab, seed=0), NeuralBigram(vocab, seed=0)
    plain.fit(xs, ys, epochs=150, lr=50.0, reg=0.0)
    reg.fit(xs, ys, epochs=150, lr=50.0, reg=0.1)
    assert np.sum(reg.W**2) < np.sum(plain.W**2)


# -------------------------------- sampling --------------------------------- #
def test_generate_is_reproducible_and_stays_in_vocabulary():
    names = load_names(DATA)
    vocab = Vocab.from_names(names)
    probs = CountingBigram(vocab).fit(names).probs(alpha=0.1)
    a = generate(probs, vocab, 20, np.random.default_rng(7))
    b = generate(probs, vocab, 20, np.random.default_rng(7))
    assert a == b and len(a) == 20
    assert all(n and set(n) <= set(vocab.itos) - {"."} for n in a)


def test_generate_terminates_even_if_end_token_is_unreachable():
    vocab = Vocab.from_names(["ab"])
    probs = np.zeros((len(vocab), len(vocab)))
    probs[:, vocab.stoi["a"]] = 1.0  # always emits 'a', never '.'
    out = generate(probs, vocab, 3, np.random.default_rng(0), max_len=12)
    assert out == ["a" * 12] * 3


def test_generate_respects_min_len_and_validates_shape():
    vocab = Vocab.from_names(["ab"])
    probs = CountingBigram(vocab).fit(["ab"]).probs(alpha=0.5)
    assert all(len(n) >= 2 for n in generate(probs, vocab, 15, np.random.default_rng(0), min_len=2))
    with pytest.raises(ValueError):
        generate(np.ones((2, 2)) / 2, vocab, 1, np.random.default_rng(0))
