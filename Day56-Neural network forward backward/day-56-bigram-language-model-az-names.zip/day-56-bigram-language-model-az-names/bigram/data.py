"""Loading, normalising, splitting and encoding a list of names."""

from __future__ import annotations

import random
import unicodedata
from pathlib import Path
from typing import Dict, List, Sequence, Tuple, Union

import numpy as np

AZ_ALPHABET = "abcçdeəfgğhxıijkqlmnoöprsştuüvyz"  # the 32 letters of the Azerbaijani Latin alphabet
END_TOKEN = "."  # marks both the start and the end of a name; always has index 0


def az_lower(text: str) -> str:
    """Lowercase using Azerbaijani rules.

    Python's default ``"İ".lower()`` returns TWO code points (``i`` plus a combining dot), which
    would silently add a bogus character to the vocabulary. In Azerbaijani, ``İ -> i`` and ``I -> ı``.
    """
    text = text.replace("İ", "i").replace("I", "ı")
    return unicodedata.normalize("NFC", text.lower())


def load_names(path: Union[str, Path], unique: bool = True) -> List[str]:
    """Read one name per line (UTF-8), normalise it and validate that it contains only letters.

    Blank lines and lines starting with ``#`` are ignored.
    """
    names: List[str] = []
    seen = set()
    with open(path, encoding="utf-8") as f:
        for line_no, raw in enumerate(f, start=1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            name = az_lower(line)
            if not name.isalpha():
                raise ValueError(f"{path}:{line_no}: {line!r} contains non-letter characters")
            if unique:
                if name in seen:
                    continue
                seen.add(name)
            names.append(name)
    if not names:
        raise ValueError(f"No names found in {path}")
    return names


def split_names(
    names: Sequence[str], fractions: Tuple[float, float, float] = (0.8, 0.1, 0.1), seed: int = 42
) -> Tuple[List[str], List[str], List[str]]:
    """Deterministic shuffle-and-split into (train, dev, test)."""
    if len(fractions) != 3 or abs(sum(fractions) - 1.0) > 1e-9 or min(fractions) < 0:
        raise ValueError("fractions must be three non-negative numbers summing to 1")
    shuffled = list(names)
    random.Random(seed).shuffle(shuffled)
    n_train = int(fractions[0] * len(shuffled))
    n_dev = int(fractions[1] * len(shuffled))
    return shuffled[:n_train], shuffled[n_train : n_train + n_dev], shuffled[n_train + n_dev :]


class Vocab:
    """Maps characters to integer ids. Index 0 is always the start/end token ``.``."""

    def __init__(self, chars: Sequence[str]) -> None:
        letters = sorted(set(chars) - {END_TOKEN})
        self.itos: List[str] = [END_TOKEN] + letters
        self.stoi: Dict[str, int] = {c: i for i, c in enumerate(self.itos)}

    @classmethod
    def from_names(cls, names: Sequence[str]) -> "Vocab":
        return cls("".join(names))

    def __len__(self) -> int:
        return len(self.itos)

    def encode(self, text: str) -> List[int]:
        try:
            return [self.stoi[c] for c in text]
        except KeyError as e:
            raise KeyError(f"Character {e.args[0]!r} is not in the vocabulary") from None

    def decode(self, ids: Sequence[int]) -> str:
        return "".join(self.itos[i] for i in ids)


def bigrams(names: Sequence[str], vocab: Vocab) -> Tuple[np.ndarray, np.ndarray]:
    """All (current, next) character-id pairs, with ``.`` padding at both ends of every name."""
    xs: List[int] = []
    ys: List[int] = []
    for name in names:
        ids = vocab.encode(END_TOKEN + name + END_TOKEN)
        xs.extend(ids[:-1])
        ys.extend(ids[1:])
    return np.asarray(xs, dtype=np.int64), np.asarray(ys, dtype=np.int64)
