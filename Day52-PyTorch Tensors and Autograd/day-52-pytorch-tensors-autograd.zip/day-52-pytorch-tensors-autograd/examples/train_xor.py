"""Train a small MLP on XOR using only the from-scratch autograd engine."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from micrograd import MLP  # noqa: E402

XS = [[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]]
YS = [-1.0, 1.0, 1.0, -1.0]  # XOR encoded as {-1, +1} for a tanh output range


def main(epochs: int = 200, lr: float = 0.05) -> None:
    model = MLP(2, [4, 4, 1], seed=0)
    print(f"Parameters: {len(model.parameters())}")

    for epoch in range(epochs + 1):
        preds = [model(x) for x in XS]
        loss = sum((p - y) ** 2 for p, y in zip(preds, YS))

        model.zero_grad()  # clear stale gradients BEFORE backward
        loss.backward()
        for p in model.parameters():
            p.data -= lr * p.grad  # vanilla gradient descent

        if epoch % 25 == 0:
            print(f"epoch {epoch:3d} | loss {loss.data:.6f}")

    print("\nPredictions after training:")
    for x, y in zip(XS, YS):
        print(f"  input={x} target={y:+.0f} prediction={model(x).data:+.4f}")


if __name__ == "__main__":
    main()
