"""Counting bigram model on Azerbaijani names: smoothing sweep, evaluation and sampling."""

import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
# Optional: pass your own dataset (one name per line):  python examples/count_bigram.py my_names.txt
DATA_PATH = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "data" / "names_az.txt"

from bigram import CountingBigram, Vocab, load_names, split_names  # noqa: E402


def main() -> None:
    names = load_names(DATA_PATH)
    train, dev, test = split_names(names, seed=42)
    vocab = Vocab.from_names(names)  # built on ALL names so dev/test characters are always known

    print(f"{len(names)} names | train {len(train)} dev {len(dev)} test {len(test)} | vocab {len(vocab)} (incl. '.')")
    print("vocabulary:", "".join(vocab.itos))

    model = CountingBigram(vocab).fit(train)
    print("\nMost common bigrams ('.' = start/end of a name):")
    print("  " + "  ".join(f"{b}:{c}" for b, c in model.top_bigrams(12)))

    print(f"\nUniform baseline NLL = ln({len(vocab)}) = {math.log(len(vocab)):.4f}")
    print("\nAdd-alpha smoothing sweep (average NLL per bigram):")
    print(f"  {'alpha':>6} {'train':>9} {'dev':>9}")
    best_alpha, best_dev = None, math.inf
    for alpha in (0.0, 0.01, 0.05, 0.1, 0.3, 0.5, 1.0, 2.0):
        tr, dv = model.nll(train, alpha), model.nll(dev, alpha)
        marker = ""
        if dv < best_dev:
            best_alpha, best_dev, marker = alpha, dv, " <- best so far"
        print(f"  {alpha:>6} {tr:>9.4f} {dv:>9.4f}{marker}")
    print("\nWith alpha = 0 any dev bigram unseen in training has probability 0, so the loss is infinite.")

    print(f"\nChosen alpha = {best_alpha} (lowest dev loss)")
    print(f"Test NLL = {model.nll(test, best_alpha):.4f} | perplexity = {math.exp(model.nll(test, best_alpha)):.2f}"
          f" (uniform would be {len(vocab)})")

    rng = np.random.default_rng(2147483647)
    samples = model.sample(20, rng, alpha=best_alpha, min_len=2)
    known = set(names)
    print("\nSampled names:")
    print("  " + ", ".join(f"{s}{'*' if s in known else ''}" for s in samples))
    print("  (* = exists in the dataset)")

    many = model.sample(2000, np.random.default_rng(0), alpha=best_alpha, min_len=2)
    print(f"\nOf 2000 samples: {np.mean([s in known for s in many]):.1%} are real dataset names, "
          f"mean length {np.mean([len(s) for s in many]):.1f} (dataset: {np.mean([len(n) for n in names]):.1f})")


if __name__ == "__main__":
    main()
