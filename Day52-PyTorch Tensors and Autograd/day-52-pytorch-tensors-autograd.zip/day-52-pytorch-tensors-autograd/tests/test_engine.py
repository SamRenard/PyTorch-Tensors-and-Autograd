"""Unit tests for the autograd engine.

Gradients are validated three ways: against hand-derived values, against
numerical finite differences, and (when installed) against PyTorch.
"""

import random

import pytest

from micrograd import MLP, Value


def numerical_grad(f, x, eps=1e-6):
    return (f(x + eps) - f(x - eps)) / (2 * eps)


def test_add_mul_gradients():
    a, b = Value(2.0), Value(-3.0)
    c = a * b + a
    c.backward()
    assert c.data == -4.0
    assert a.grad == pytest.approx(b.data + 1)  # dc/da = b + 1
    assert b.grad == pytest.approx(a.data)  # dc/db = a


def test_reused_node_accumulates_gradient():
    a = Value(3.0)
    b = a + a  # db/da = 2
    b.backward()
    assert a.grad == 2.0


def test_reflected_operators():
    a = Value(4.0)
    out = 2 + a - 1 + 3 * a - 8 / a
    out.backward()
    assert out.data == pytest.approx(2 + 4 - 1 + 12 - 2)
    assert a.grad == pytest.approx(1 + 3 + 8 / 16)


def test_pow_and_div():
    a = Value(2.0)
    out = (a**3) / Value(4.0)
    out.backward()
    assert out.data == pytest.approx(2.0)
    assert a.grad == pytest.approx(3 * 4 / 4)


@pytest.mark.parametrize(
    "name, fn, x0",
    [
        ("tanh", lambda v: v.tanh(), 0.7),
        ("relu+", lambda v: v.relu(), 1.3),
        ("relu-", lambda v: v.relu(), -1.3),
        ("sigmoid", lambda v: v.sigmoid(), -0.4),
        ("exp", lambda v: v.exp(), 0.5),
        ("log", lambda v: v.log(), 2.5),
    ],
)
def test_unary_ops_match_finite_differences(name, fn, x0):
    x = Value(x0)
    out = fn(x)
    out.backward()
    expected = numerical_grad(lambda t: fn(Value(t)).data, x0)
    assert x.grad == pytest.approx(expected, rel=1e-5, abs=1e-8)


def test_sigmoid_is_stable_for_large_inputs():
    assert Value(-1000.0).sigmoid().data == pytest.approx(0.0, abs=1e-12)
    assert Value(1000.0).sigmoid().data == pytest.approx(1.0, abs=1e-12)


def test_log_rejects_non_positive():
    with pytest.raises(ValueError):
        Value(0.0).log()


def test_karpathy_reference_expression():
    x1, x2 = Value(2.0), Value(0.0)
    w1, w2 = Value(-3.0), Value(1.0)
    b = Value(6.8813735870195432)
    o = (x1 * w1 + x2 * w2 + b).tanh()
    o.backward()
    assert o.data == pytest.approx(0.7071, abs=1e-4)
    assert x1.grad == pytest.approx(-1.5, abs=1e-3)
    assert w1.grad == pytest.approx(1.0, abs=1e-3)
    assert x2.grad == pytest.approx(0.5, abs=1e-3)


def test_deep_graph_does_not_hit_recursion_limit():
    x = Value(1.0)
    out = x
    for _ in range(5000):
        out = out + 0.0
    out.backward()
    assert x.grad == 1.0


def test_mlp_training_reduces_loss():
    xs = [[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]]
    ys = [-1.0, 1.0, 1.0, -1.0]
    model = MLP(2, [4, 4, 1], seed=0)

    def loss_fn():
        return sum((model(x) - y) ** 2 for x, y in zip(xs, ys))

    initial = loss_fn().data
    for _ in range(100):
        loss = loss_fn()
        model.zero_grad()
        loss.backward()
        for p in model.parameters():
            p.data -= 0.05 * p.grad
    assert loss_fn().data < initial * 0.1


def test_matches_pytorch():
    torch = pytest.importorskip("torch")
    rng = random.Random(1)
    vals = [rng.uniform(-2, 2) for _ in range(3)]

    a, b, c = (Value(v) for v in vals)
    out = ((a * b + c**2).tanh() + (a - c).relu()) / (1 + b.sigmoid())
    out.backward()

    ta, tb, tc = (torch.tensor(v, dtype=torch.float64, requires_grad=True) for v in vals)
    tout = (torch.tanh(ta * tb + tc**2) + torch.relu(ta - tc)) / (1 + torch.sigmoid(tb))
    tout.backward()

    assert out.data == pytest.approx(tout.item())
    for mine, theirs in ((a, ta), (b, tb), (c, tc)):
        assert mine.grad == pytest.approx(theirs.grad.item(), rel=1e-9)
