"""Backpropagation on a tiny network, one quantity at a time, checked three ways.

Network: 2 -> 3 (tanh) -> 2 (softmax cross-entropy), a single training sample.
Every gradient is derived by hand below, then compared with MLP.backward and
with numerical finite differences.
"""

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from nn_numpy import MLP, numerical_gradient, relative_error, softmax  # noqa: E402

np.set_printoptions(precision=5, suppress=True)


def main() -> None:
    net = MLP([2, 3, 2], activation="tanh", seed=0)
    x = np.array([[0.5, -1.0]])
    y = np.array([1])  # the true class

    W1, b1, W2, b2 = (net.params[k] for k in ("W1", "b1", "W2", "b2"))

    print("=== FORWARD ===")
    z1 = x @ W1 + b1
    a1 = np.tanh(z1)
    z2 = a1 @ W2 + b2
    p = softmax(z2)
    loss = -np.log(p[0, y[0]])
    print("z1 =", z1[0], "\na1 = tanh(z1) =", a1[0])
    print("z2 (logits) =", z2[0], "\np = softmax(z2) =", p[0])
    print(f"loss = -log(p[true class]) = {loss:.5f}")

    print("\n=== BACKWARD (derived by hand) ===")
    one_hot = np.eye(2)[y]
    dz2 = p - one_hot  # softmax + cross-entropy collapses to p - y   (N = 1)
    print("dz2 = p - one_hot            =", dz2[0])
    dW2 = a1.T @ dz2
    db2 = dz2.sum(axis=0)
    print("dW2 = a1.T @ dz2             =\n", dW2)
    print("db2 = dz2                    =", db2)
    da1 = dz2 @ W2.T
    print("da1 = dz2 @ W2.T             =", da1[0])
    dz1 = da1 * (1.0 - a1**2)  # tanh'(z) = 1 - tanh(z)^2
    print("dz1 = da1 * (1 - a1^2)       =", dz1[0])
    dW1 = x.T @ dz1
    db1 = dz1.sum(axis=0)
    print("dW1 = x.T @ dz1              =\n", dW1)
    print("db1 = dz1                    =", db1)

    print("\n=== VERIFICATION ===")
    net.forward(x)
    code = net.backward(y)
    hand = {"W1": dW1, "b1": db1, "W2": dW2, "b2": db2}
    print(f"{'param':<6}{'hand vs MLP.backward':>24}{'hand vs numerical':>22}")
    for name, g in hand.items():
        numeric = numerical_gradient(lambda: net.loss(x, y), net.params[name])
        print(f"{name:<6}{relative_error(g, code[name]):>24.2e}{relative_error(g, numeric):>22.2e}")
    print("\nRelative errors near 1e-10 / 1e-9 mean the derivation is correct.")


if __name__ == "__main__":
    main()
