"""Fully connected network of arbitrary depth with a hand-derived backward pass.

Notation (layers are numbered 1..L, ``A[0] = X``)::

    Z[i] = A[i-1] @ W[i] + b[i]          pre-activation of layer i
    A[i] = f(Z[i])                       for hidden layers i < L
    out  = Z[L]                          the last layer is linear (logits / regression output)

Backward pass (N = batch size)::

    dZ[L]   = dLoss/dout                 softmax-CE: (p - one_hot) / N     MSE: 2 (out - y) / N
    dW[i]   = A[i-1].T @ dZ[i] + l2 * W[i]
    db[i]   = sum(dZ[i], axis=0)
    dA[i-1] = dZ[i] @ W[i].T
    dZ[i-1] = dA[i-1] * f'(Z[i-1])       the chain rule through the activation
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence

import numpy as np

from .activations import ACTIVATIONS, log_softmax, softmax

Array = np.ndarray
LOSSES = ("cross_entropy", "mse")


class MLP:
    """Multi-layer perceptron.

    Args:
        layer_sizes: ``[n_in, hidden_1, ..., n_out]`` (at least two entries).
        activation: hidden-layer activation: ``relu``, ``sigmoid`` or ``tanh``.
        loss: ``cross_entropy`` (integer class labels, softmax output) or
            ``mse`` (float targets of shape ``(N, n_out)``).
        l2: L2 weight-decay strength. Adds ``0.5 * l2 * sum(W**2)`` to the loss.
        seed: seed for reproducible initialisation.
    """

    def __init__(
        self,
        layer_sizes: Sequence[int],
        activation: str = "relu",
        loss: str = "cross_entropy",
        l2: float = 0.0,
        seed: Optional[int] = 0,
    ) -> None:
        sizes = [int(s) for s in layer_sizes]
        if len(sizes) < 2 or min(sizes) < 1:
            raise ValueError("layer_sizes needs at least [n_in, n_out], all positive.")
        if activation not in ACTIVATIONS:
            raise ValueError(f"Unknown activation {activation!r}; choose from {sorted(ACTIVATIONS)}")
        if loss not in LOSSES:
            raise ValueError(f"Unknown loss {loss!r}; choose from {LOSSES}")
        if l2 < 0:
            raise ValueError("l2 must be non-negative.")

        self.sizes = sizes
        self.L = len(sizes) - 1  # number of weight layers
        self.activation = activation
        self.loss_name = loss
        self.l2 = float(l2)
        self._act, self._act_grad = ACTIVATIONS[activation]

        rng = np.random.default_rng(seed)
        gain = 2.0 if activation == "relu" else 1.0  # He for ReLU, Xavier-style otherwise
        self.params: Dict[str, Array] = {}
        for i in range(1, self.L + 1):
            fan_in, fan_out = sizes[i - 1], sizes[i]
            self.params[f"W{i}"] = rng.standard_normal((fan_in, fan_out)) * np.sqrt(gain / fan_in)
            self.params[f"b{i}"] = np.zeros(fan_out)
        self._cache: Dict[str, List[Array]] = {}

    # ------------------------------------------------------------------ #
    # Forward
    # ------------------------------------------------------------------ #
    def forward(self, X: Array) -> Array:
        """Return the output of the last layer and cache intermediates for backward()."""
        X = self._check_input(X)
        A: List[Array] = [X]
        Z: List[Array] = []
        for i in range(1, self.L + 1):
            z = A[-1] @ self.params[f"W{i}"] + self.params[f"b{i}"]
            Z.append(z)
            if i < self.L:
                A.append(self._act(z))
        self._cache = {"A": A, "Z": Z}
        return Z[-1]

    def predict_proba(self, X: Array) -> Array:
        self._require_loss("cross_entropy", "predict_proba")
        return softmax(self.forward(X))

    def predict(self, X: Array) -> Array:
        out = self.forward(X)
        return np.argmax(out, axis=1) if self.loss_name == "cross_entropy" else out

    def accuracy(self, X: Array, y: Array) -> float:
        self._require_loss("cross_entropy", "accuracy")
        return float(np.mean(self.predict(X) == y))

    # ------------------------------------------------------------------ #
    # Loss
    # ------------------------------------------------------------------ #
    def loss(self, X: Array, y: Array) -> float:
        """Data loss (mean over the batch) plus the L2 penalty."""
        out = self.forward(X)
        y = self._prepare_targets(y, len(out))
        if self.loss_name == "cross_entropy":
            data = -np.mean(log_softmax(out)[np.arange(len(y)), y])
        else:
            data = np.sum((out - y) ** 2) / len(y)
        return float(data + self._l2_penalty())

    def _l2_penalty(self) -> float:
        if self.l2 == 0.0:
            return 0.0
        return 0.5 * self.l2 * sum(float(np.sum(self.params[f"W{i}"] ** 2)) for i in range(1, self.L + 1))

    # ------------------------------------------------------------------ #
    # Backward
    # ------------------------------------------------------------------ #
    def backward(self, y: Array) -> Dict[str, Array]:
        """Gradients of ``loss`` with respect to every parameter. Needs a prior forward()."""
        if not self._cache:
            raise RuntimeError("Call forward() before backward().")
        A, Z = self._cache["A"], self._cache["Z"]
        n = A[0].shape[0]
        y = self._prepare_targets(y, n)

        # Gradient of the loss at the output layer.
        if self.loss_name == "cross_entropy":
            dz = softmax(Z[-1])
            dz[np.arange(n), y] -= 1.0
            dz /= n
        else:
            dz = 2.0 * (Z[-1] - y) / n

        grads: Dict[str, Array] = {}
        for i in range(self.L, 0, -1):
            W = self.params[f"W{i}"]
            grads[f"W{i}"] = A[i - 1].T @ dz + self.l2 * W
            grads[f"b{i}"] = dz.sum(axis=0)
            if i > 1:
                da = dz @ W.T  # propagate to the previous layer's activation
                dz = da * self._act_grad(Z[i - 2])  # then through its non-linearity
        return grads

    # ------------------------------------------------------------------ #
    # Training
    # ------------------------------------------------------------------ #
    def step(self, grads: Dict[str, Array], lr: float) -> None:
        for name, g in grads.items():
            self.params[name] -= lr * g

    def fit(
        self,
        X: Array,
        y: Array,
        epochs: int = 100,
        lr: float = 0.1,
        batch_size: Optional[int] = None,
        seed: Optional[int] = 0,
    ) -> List[float]:
        """Gradient descent. ``batch_size=None`` means full batch; otherwise shuffled mini-batches.

        Returns the full-dataset loss measured at the end of every epoch.
        """
        X = self._check_input(X)
        y = self._prepare_targets(y, len(X))
        if batch_size is not None and batch_size < 1:
            raise ValueError("batch_size must be a positive integer or None.")
        n = len(X)
        bs = n if batch_size is None else batch_size
        rng = np.random.default_rng(seed)

        history: List[float] = []
        for _ in range(epochs):
            order = rng.permutation(n) if bs < n else np.arange(n)
            for start in range(0, n, bs):
                idx = order[start : start + bs]
                self.forward(X[idx])
                self.step(self.backward(y[idx]), lr)
            history.append(self.loss(X, y))
        return history

    def num_parameters(self) -> int:
        return int(sum(v.size for v in self.params.values()))

    # ------------------------------------------------------------------ #
    # Validation helpers
    # ------------------------------------------------------------------ #
    def _check_input(self, X: Array) -> Array:
        X = np.asarray(X, dtype=float)
        if X.ndim != 2 or X.shape[1] != self.sizes[0]:
            raise ValueError(f"Expected input of shape (N, {self.sizes[0]}), got {X.shape}.")
        return X

    def _prepare_targets(self, y: Array, n: int) -> Array:
        if self.loss_name == "cross_entropy":
            y = np.asarray(y)
            if y.shape != (n,):
                raise ValueError(f"Expected labels of shape ({n},), got {y.shape}.")
            if not np.issubdtype(y.dtype, np.integer):
                raise TypeError("cross_entropy needs integer class labels.")
            if y.min() < 0 or y.max() >= self.sizes[-1]:
                raise ValueError(f"Labels must be in [0, {self.sizes[-1]}).")
            return y
        y = np.asarray(y, dtype=float)
        if y.ndim == 1 and self.sizes[-1] == 1:
            y = y[:, None]
        if y.shape != (n, self.sizes[-1]):
            raise ValueError(f"Expected targets of shape ({n}, {self.sizes[-1]}), got {y.shape}.")
        return y

    def _require_loss(self, expected: str, what: str) -> None:
        if self.loss_name != expected:
            raise ValueError(f"{what}() is only available for loss={expected!r}.")

    def __repr__(self) -> str:
        arch = " -> ".join(str(s) for s in self.sizes)
        return f"MLP({arch}, hidden={self.activation}, loss={self.loss_name}, {self.num_parameters()} parameters)"
