"""Step-by-step forward pass: a hand-checkable example, then MNIST-sized shapes."""

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from nn_numpy import TwoLayerNet, softmax  # noqa: E402


def tiny_example() -> None:
    print("=== Tiny network (2 -> 2 -> 2), verifiable by hand ===")
    W1 = np.array([[1.0, -1.0], [0.5, 2.0]])
    b1 = np.array([0.0, 0.5])
    W2 = np.array([[1.0, 2.0], [-1.0, 1.0]])
    b2 = np.array([0.1, -0.1])
    x = np.array([[2.0, 1.0]])

    z1 = x @ W1 + b1
    a1 = np.maximum(0.0, z1)
    z2 = a1 @ W2 + b2
    probs = softmax(z2)

    print("x      =", x[0])
    print("z1     =", z1[0], " (x @ W1 + b1)")
    print("a1     =", a1[0], " (ReLU)")
    print("z2     =", z2[0], " (a1 @ W2 + b2, the logits)")
    print("probs  =", np.round(probs[0], 4), " (softmax, sums to 1)")

    net = TwoLayerNet(2, 2, 2, activation="relu")
    net.params.update({"W1": W1, "b1": b1, "W2": W2, "b2": b2})
    assert np.allclose(net.forward(x), z2)
    print("TwoLayerNet.forward agrees with the manual computation.\n")


def mnist_shapes() -> None:
    print("=== MNIST-sized network (784 -> 16 -> 10) ===")
    net = TwoLayerNet(784, 16, 10, activation="relu", seed=0)
    print(net)

    batch = np.random.default_rng(0).random((5, 784))  # stand-in for 5 flattened 28x28 images
    logits = net.forward(batch)
    probs = net.predict_proba(batch)
    print("input  :", batch.shape)
    print("logits :", logits.shape)
    print("probs  :", probs.shape, "| row sums:", np.round(probs.sum(axis=1), 6))
    print("untrained predictions:", net.predict(batch), "(essentially random)")


if __name__ == "__main__":
    tiny_example()
    mnist_shapes()
