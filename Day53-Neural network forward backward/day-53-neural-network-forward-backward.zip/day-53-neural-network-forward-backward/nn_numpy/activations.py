"""Activation functions and their derivatives.

Every ``*_grad`` function takes the *pre-activation* ``z`` (the input of the
activation) and returns d(activation)/dz, which is exactly what the backward
pass needs.
"""

from __future__ import annotations

from typing import Callable, Dict, Tuple

import numpy as np

Array = np.ndarray


def relu(z: Array) -> Array:
    return np.maximum(0.0, z)


def relu_grad(z: Array) -> Array:
    return (np.asarray(z) > 0).astype(float)


def sigmoid(z: Array) -> Array:
    """Numerically stable logistic function (never exponentiates a large positive number)."""
    z = np.asarray(z, dtype=float)
    e = np.exp(-np.abs(z))
    return np.where(z >= 0, 1.0 / (1.0 + e), e / (1.0 + e))


def sigmoid_grad(z: Array) -> Array:
    s = sigmoid(z)
    return s * (1.0 - s)


def tanh(z: Array) -> Array:
    return np.tanh(z)


def tanh_grad(z: Array) -> Array:
    t = np.tanh(z)
    return 1.0 - t * t


def log_softmax(z: Array, axis: int = -1) -> Array:
    """log(softmax(z)) computed with the log-sum-exp trick for stability."""
    shifted = z - np.max(z, axis=axis, keepdims=True)
    return shifted - np.log(np.sum(np.exp(shifted), axis=axis, keepdims=True))


def softmax(z: Array, axis: int = -1) -> Array:
    return np.exp(log_softmax(z, axis=axis))


ACTIVATIONS: Dict[str, Tuple[Callable[[Array], Array], Callable[[Array], Array]]] = {
    "relu": (relu, relu_grad),
    "sigmoid": (sigmoid, sigmoid_grad),
    "tanh": (tanh, tanh_grad),
}
