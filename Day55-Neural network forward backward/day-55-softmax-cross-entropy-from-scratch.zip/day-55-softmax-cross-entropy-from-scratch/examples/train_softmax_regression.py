"""Train a softmax-regression classifier on 8x8 digits using only our CrossEntropyLoss.

Requires: pip install scikit-learn   (the dataset ships with the package, no download needed)
"""

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from losses import CrossEntropyLoss  # noqa: E402

try:
    from sklearn.datasets import load_digits
except ImportError:  # pragma: no cover
    sys.exit("This example needs scikit-learn:  pip install scikit-learn")


def main() -> None:
    data = load_digits()
    X, y = data.data / 16.0, data.target.astype(int)

    rng = np.random.default_rng(0)
    order = rng.permutation(len(X))
    split = int(0.8 * len(X))
    train, test = order[:split], order[split:]

    W, b = np.zeros((64, 10)), np.zeros(10)
    ce = CrossEntropyLoss()

    def accuracy(idx):
        return float(np.mean(np.argmax(X[idx] @ W + b, axis=1) == y[idx]))

    print(f"train {len(train)} | test {len(test)} | initial loss {ce(X[train] @ W + b, y[train]):.4f} (ln 10 = {np.log(10):.4f})")
    for epoch in range(1, 31):
        perm = rng.permutation(train)
        for start in range(0, len(perm), 64):
            idx = perm[start : start + 64]
            ce(X[idx] @ W + b, y[idx])
            d_logits = ce.backward()  # (p - one_hot) / batch
            W -= 0.5 * (X[idx].T @ d_logits)
            b -= 0.5 * d_logits.sum(axis=0)
        if epoch in (1, 5, 10, 20, 30):
            print(f"epoch {epoch:2d} | train loss {ce(X[train] @ W + b, y[train]):.4f} | test acc {accuracy(test):.1%}")

    print(f"Final: train accuracy {accuracy(train):.1%} | test accuracy {accuracy(test):.1%}")


if __name__ == "__main__":
    main()
