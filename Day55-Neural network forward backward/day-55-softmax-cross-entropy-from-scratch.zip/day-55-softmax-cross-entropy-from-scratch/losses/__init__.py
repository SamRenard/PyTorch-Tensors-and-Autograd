"""Softmax, cross-entropy, MSE and BCE-with-logits implemented from scratch in NumPy."""

from .functional import (
    REDUCTIONS,
    bce_with_logits,
    bce_with_logits_grad,
    cross_entropy,
    cross_entropy_grad,
    log_softmax,
    logsumexp,
    mse_loss,
    mse_loss_grad,
    sigmoid,
    softmax,
)
from .gradcheck import numerical_gradient, relative_error
from .modules import BCEWithLogitsLoss, CrossEntropyLoss, MSELoss

__all__ = [
    "REDUCTIONS",
    "softmax",
    "log_softmax",
    "logsumexp",
    "sigmoid",
    "cross_entropy",
    "cross_entropy_grad",
    "mse_loss",
    "mse_loss_grad",
    "bce_with_logits",
    "bce_with_logits_grad",
    "CrossEntropyLoss",
    "MSELoss",
    "BCEWithLogitsLoss",
    "numerical_gradient",
    "relative_error",
]
__version__ = "0.1.0"
