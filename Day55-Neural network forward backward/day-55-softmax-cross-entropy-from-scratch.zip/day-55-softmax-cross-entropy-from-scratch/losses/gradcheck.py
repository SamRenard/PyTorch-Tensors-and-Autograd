"""Finite-difference gradient checking helpers."""

from __future__ import annotations

from typing import Callable

import numpy as np

Array = np.ndarray


def numerical_gradient(f: Callable[[], float], x: Array, eps: float = 1e-6) -> Array:
    """Central-difference gradient of the scalar ``f()`` with respect to ``x`` (restored afterwards)."""
    grad = np.zeros_like(x)
    it = np.nditer(x, flags=["multi_index"])
    for _ in it:
        i = it.multi_index
        original = x[i]
        x[i] = original + eps
        plus = f()
        x[i] = original - eps
        minus = f()
        x[i] = original
        grad[i] = (plus - minus) / (2.0 * eps)
    return grad


def relative_error(a: Array, b: Array) -> float:
    """``||a - b|| / (||a|| + ||b||)``; 0 when both are zero."""
    denom = np.linalg.norm(a) + np.linalg.norm(b)
    return float(np.linalg.norm(a - b) / max(denom, 1e-12))
