# Dataset: `names_az.txt`

388 unique Azerbaijani given names (male and female), one per line, lowercase, UTF-8.

**Provenance.** A starter list compiled by hand from general knowledge, *not* scraped from an official
registry. It may contain rare variants and is far smaller than the 32,000-name English dataset used in the
original makemore lecture, so treat the model's absolute numbers accordingly.

**Using your own data.** Any UTF-8 file with one name per line works:

```bash
python examples/count_bigram.py path/to/my_names.txt
```

The loader lowercases with Azerbaijani rules (`İ -> i`, `I -> ı`), removes duplicates, ignores blank lines
and `#` comments, and rejects lines containing spaces, digits or punctuation.
