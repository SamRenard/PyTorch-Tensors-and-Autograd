"""A fully connected network: input -> hidden (activation) -> output (softmax)."""

from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np

from .activations import ACTIVATIONS, log_softmax, softmax

Array = np.ndarray


class TwoLayerNet:
    """Classifier with a single hidden layer.

    Shapes (N = batch size)::

        X  : (N, n_in)
        W1 : (n_in, n_hidden)   b1 : (n_hidden,)
        W2 : (n_hidden, n_out)  b2 : (n_out,)

    Forward pass::

        z1 = X @ W1 + b1
        a1 = activation(z1)
        z2 = a1 @ W2 + b2        # logits
        p  = softmax(z2)         # class probabilities
    """

    def __init__(
        self,
        n_in: int,
        n_hidden: int,
        n_out: int,
        activation: str = "relu",
        seed: Optional[int] = 0,
    ) -> None:
        if activation not in ACTIVATIONS:
            raise ValueError(f"Unknown activation {activation!r}; choose from {sorted(ACTIVATIONS)}")
        if min(n_in, n_hidden, n_out) < 1:
            raise ValueError("Layer sizes must be positive integers.")

        self.n_in, self.n_hidden, self.n_out = n_in, n_hidden, n_out
        self.activation = activation
        self._act, self._act_grad = ACTIVATIONS[activation]

        rng = np.random.default_rng(seed)
        # He initialisation for ReLU, Xavier-style for saturating activations.
        gain = 2.0 if activation == "relu" else 1.0
        self.params: Dict[str, Array] = {
            "W1": rng.standard_normal((n_in, n_hidden)) * np.sqrt(gain / n_in),
            "b1": np.zeros(n_hidden),
            "W2": rng.standard_normal((n_hidden, n_out)) * np.sqrt(1.0 / n_hidden),
            "b2": np.zeros(n_out),
        }
        self._cache: Dict[str, Array] = {}

    # ------------------------------------------------------------------ #
    # Forward
    # ------------------------------------------------------------------ #
    def forward(self, X: Array) -> Array:
        """Return logits of shape (N, n_out) and cache intermediates for backward()."""
        X = self._check_input(X)
        p = self.params
        z1 = X @ p["W1"] + p["b1"]
        a1 = self._act(z1)
        z2 = a1 @ p["W2"] + p["b2"]
        self._cache = {"X": X, "z1": z1, "a1": a1, "z2": z2}
        return z2

    def predict_proba(self, X: Array) -> Array:
        return softmax(self.forward(X))

    def predict(self, X: Array) -> Array:
        return np.argmax(self.forward(X), axis=1)

    def accuracy(self, X: Array, y: Array) -> float:
        return float(np.mean(self.predict(X) == y))

    # ------------------------------------------------------------------ #
    # Loss and backward
    # ------------------------------------------------------------------ #
    def loss(self, X: Array, y: Array) -> float:
        """Mean cross-entropy of softmax(logits) against integer labels."""
        y = self._check_labels(y, len(X))
        log_probs = log_softmax(self.forward(X))
        return float(-np.mean(log_probs[np.arange(len(y)), y]))

    def backward(self, y: Array) -> Dict[str, Array]:
        """Gradients of the mean cross-entropy loss. Requires a prior forward()."""
        if not self._cache:
            raise RuntimeError("Call forward() before backward().")
        c, p = self._cache, self.params
        n = c["X"].shape[0]
        y = self._check_labels(y, n)

        # Softmax + cross-entropy collapses to (probs - one_hot) / N.
        dz2 = softmax(c["z2"])
        dz2[np.arange(n), y] -= 1.0
        dz2 /= n

        dW2 = c["a1"].T @ dz2
        db2 = dz2.sum(axis=0)

        da1 = dz2 @ p["W2"].T
        dz1 = da1 * self._act_grad(c["z1"])  # chain rule through the activation
        dW1 = c["X"].T @ dz1
        db1 = dz1.sum(axis=0)
        return {"W1": dW1, "b1": db1, "W2": dW2, "b2": db2}

    # ------------------------------------------------------------------ #
    # Training helpers
    # ------------------------------------------------------------------ #
    def step(self, grads: Dict[str, Array], lr: float) -> None:
        for name, g in grads.items():
            self.params[name] -= lr * g  # in-place: no new arrays per step

    def fit(self, X: Array, y: Array, epochs: int = 100, lr: float = 0.1) -> List[float]:
        """Full-batch gradient descent. Returns the loss recorded at every epoch."""
        history: List[float] = []
        for _ in range(epochs):
            logits = self.forward(X)
            history.append(float(-np.mean(log_softmax(logits)[np.arange(len(y)), y])))
            self.step(self.backward(y), lr)
        return history

    def num_parameters(self) -> int:
        return int(sum(v.size for v in self.params.values()))

    # ------------------------------------------------------------------ #
    # Validation
    # ------------------------------------------------------------------ #
    def _check_input(self, X: Array) -> Array:
        X = np.asarray(X, dtype=float)
        if X.ndim != 2 or X.shape[1] != self.n_in:
            raise ValueError(f"Expected input of shape (N, {self.n_in}), got {X.shape}.")
        return X

    def _check_labels(self, y: Array, n: int) -> Array:
        y = np.asarray(y)
        if y.shape != (n,):
            raise ValueError(f"Expected labels of shape ({n},), got {y.shape}.")
        if not np.issubdtype(y.dtype, np.integer):
            raise TypeError("Labels must be integer class indices.")
        if y.min() < 0 or y.max() >= self.n_out:
            raise ValueError(f"Labels must be in [0, {self.n_out}).")
        return y

    def __repr__(self) -> str:
        return (
            f"TwoLayerNet({self.n_in} -> {self.n_hidden} [{self.activation}] -> {self.n_out} "
            f"[softmax], {self.num_parameters()} parameters)"
        )
